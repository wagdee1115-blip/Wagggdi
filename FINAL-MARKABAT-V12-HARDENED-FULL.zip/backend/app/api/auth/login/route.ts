import { db } from '@/lib/db';
import { verifyPassword, signJwt } from '@/lib/auth';
import { cookies } from 'next/headers';
import { z } from 'zod';
const schema=z.object({ identifier:z.string().min(3), password:z.string().min(8) });
export async function POST(req:Request){
  try{ const p=schema.safeParse(await req.json()); if(!p.success)return Response.json({ok:false,error:'INVALID_INPUT'},{status:400});
    const u=await db.user.findFirst({where:{OR:[{phone:p.data.identifier},{email:p.data.identifier},{nationalId:p.data.identifier}]}});
    if(!u || !(await verifyPassword(p.data.password,u.passwordHash))) return Response.json({ok:false,error:'INVALID_CREDENTIALS'},{status:401});
    if(u.status==='SUSPENDED') return Response.json({ok:false,error:'ACCOUNT_SUSPENDED'},{status:403});
    const token=await signJwt({sub:u.id,role:u.role}); cookies().set('markabat_session',token,{httpOnly:true,secure:process.env.NODE_ENV==='production',sameSite:'lax',path:'/',maxAge:7*24*60*60});
    return Response.json({ok:true,user:{id:u.id,fullName:u.fullName,role:u.role,status:u.status,identityStatus:u.identityStatus,phoneStatus:u.phoneStatus}});
  }catch{return Response.json({ok:false,error:'LOGIN_FAILED'},{status:500});}
}
