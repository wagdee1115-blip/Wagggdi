import crypto from 'node:crypto';
import { db } from '@/lib/db';
import { getCurrentUser } from '@/lib/api-auth';
import { z } from 'zod';
const schema=z.object({phone:z.string().min(9)});
const hash=(v:string)=>crypto.createHash('sha256').update(v).digest('hex');
export async function POST(req:Request){try{const u=await getCurrentUser();if(!u)return Response.json({ok:false,error:'UNAUTHORIZED'},{status:401});const p=schema.safeParse(await req.json());if(!p.success)return Response.json({ok:false,error:'INVALID_INPUT'},{status:400});if(p.data.phone!==u.phone)return Response.json({ok:false,error:'PHONE_MISMATCH'},{status:403});const recent=await db.otpRecord.count({where:{operationId:u.id,phone:u.phone,createdAt:{gt:new Date(Date.now()-60_000)}}});if(recent>=1)return Response.json({ok:false,error:'OTP_RATE_LIMIT'},{status:429});const code=crypto.randomInt(100000,1000000).toString();const row=await db.otpRecord.create({data:{operationId:u.id,type:'BUYER',phone:u.phone,otpHash:hash(code),channel:'MOCK',expiresAt:new Date(Date.now()+5*60_000)}});return Response.json({ok:true,otpId:row.id,expiresAt:row.expiresAt,devCode:process.env.NODE_ENV==='development'?code:undefined});}catch{return Response.json({ok:false,error:'OTP_SEND_FAILED'},{status:500})}}
