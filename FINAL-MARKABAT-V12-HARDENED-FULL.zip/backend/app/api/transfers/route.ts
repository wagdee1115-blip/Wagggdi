import { getCurrentUser, apiError } from '@/lib/api-auth';
import { createOwnershipTransfer } from '@/lib/transfer-workflow';
import { z } from 'zod';
const schema=z.object({vehicleId:z.string().min(1),buyerId:z.string().min(1),salePrice:z.number().positive()});
export async function POST(req:Request){ try{ const u=await getCurrentUser(); if(!u)return Response.json({ok:false,error:'UNAUTHORIZED'},{status:401}); const p=schema.safeParse(await req.json()); if(!p.success)return Response.json({ok:false,error:'INVALID_INPUT',details:p.error.flatten()},{status:400}); const sale=await createOwnershipTransfer({vehicleId:p.data.vehicleId,buyerId:p.data.buyerId,sellerId:u.id,salePrice:p.data.salePrice}); return Response.json({ok:true,sale},{status:201}); }catch(e){return apiError(e)} }
