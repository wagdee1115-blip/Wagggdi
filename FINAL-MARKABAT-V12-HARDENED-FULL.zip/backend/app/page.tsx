'use client';
import { useEffect, useState } from 'react';

type Vehicle = { id:string; plateNumber:string; make:string; model:string; year:number; price:string; city:string };

export default function Home() {
  const [vehicles,setVehicles]=useState<Vehicle[]>([]);
  const [user,setUser]=useState<any>(null);
  useEffect(()=>{ Promise.all([fetch('/api/me').then(r=>r.json()),fetch('/api/vehicles').then(r=>r.json())]).then(([m,v])=>{if(m.ok)setUser(m.user);if(v.ok)setVehicles(v.vehicles)}) },[]);
  return <main className="p-6 max-w-6xl mx-auto">
    <header className="flex items-center justify-between gap-4 mb-8"><div><h1 className="text-3xl font-bold text-primary-900">مركبات</h1><p className="text-gray-600 mt-1">منصة المركبات والخدمات المرورية في اليمن</p></div><div className="text-sm">{user ? `مرحباً ${user.fullName}` : 'غير مسجل الدخول'}</div></header>
    <section className="grid grid-cols-2 md:grid-cols-3 gap-4">
      {['سوق المركبات','نقل الملكية','المخالفات','المواعيد','الفحص','المزادات'].map(s=><div key={s} className="bg-white p-5 rounded-xl shadow-sm border">{s}</div>)}
    </section>
    <section className="mt-10"><div className="flex justify-between items-center mb-4"><h2 className="text-xl font-bold">المركبات المتاحة</h2><a href="/traffic/ownership-transfer" className="bg-primary-900 text-white px-5 py-2 rounded-lg">بدء نقل ملكية</a></div>
      <div className="grid md:grid-cols-2 gap-4">{vehicles.map(v=><div key={v.id} className="bg-white border rounded-xl p-4"><div className="font-bold">{v.make} {v.model} ({v.year})</div><div className="text-sm text-gray-600 mt-1">لوحة: {v.plateNumber} · {v.city}</div><div className="mt-3 font-semibold">{v.price} ريال</div></div>)}{vehicles.length===0&&<div className="text-gray-500">لا توجد مركبات متاحة حاليًا.</div>}</div>
    </section>
  </main>
}
