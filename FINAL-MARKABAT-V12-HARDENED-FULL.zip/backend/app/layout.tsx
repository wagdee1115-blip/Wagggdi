import './globals.css';
export const metadata = { title: 'مركبات - منصة المركبات والخدمات المرورية', description: 'منصة المركبات في اليمن - بيانات تجريبية' };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <head><link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet" /></head>
      <body style={{ fontFamily: 'Tajawal, sans-serif' }} className="bg-gray-50 min-h-screen">
        {children}
      </body>
    </html>
  );
}
