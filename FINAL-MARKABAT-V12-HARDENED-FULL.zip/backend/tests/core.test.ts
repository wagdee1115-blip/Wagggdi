import { describe, expect, it } from 'vitest';
import { registerSchema, vehicleSchema } from '../lib/validations';

const fee = (vehicle: number, rate: number) => ({
  platformFeeYER: 80 * rate,
  totalYER: vehicle + 80 * rate,
  sellerPayoutYER: vehicle,
});

describe('Markabat core rules', () => {
  it('uses the fixed 80 USD platform fee', () => {
    expect(fee(10_000_000, 535)).toEqual({ platformFeeYER: 42_800, totalYER: 10_042_800, sellerPayoutYER: 10_000_000 });
  });
  it('rejects weak registration data', () => {
    expect(registerSchema.safeParse({ fullName:'A', nationalId:'1', dateOfBirth:'x', phone:'1', password:'123' }).success).toBe(false);
  });
  it('accepts valid vehicle data', () => {
    expect(vehicleSchema.safeParse({ plateNumber:'123',vin:'123456789012',make:'Toyota',model:'Camry',year:2024,price:1000000,mileage:10000,transmission:'AUTO',fuelType:'PETROL',color:'White',city:'Sanaa' }).success).toBe(true);
  });
});
