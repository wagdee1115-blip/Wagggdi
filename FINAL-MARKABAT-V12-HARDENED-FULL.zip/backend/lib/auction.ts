
// lib/auction.ts - نظام المزاد - مركبات V11 - حد أدنى 50,000 YER

export type AuctionStatus = 'DRAFT' | 'ACTIVE' | 'ENDED' | 'CANCELLED' | 'COMPLETED' | 'PAYMENT_PENDING' | 'PAYMENT_FAILED';

export interface Auction {
  id: string;
  vehicleId: string;
  vehicleData: any;
  sellerId: string;
  sellerName: string;
  minimumBidYER: number; // حد أدنى 50,000 YER - Configurable
  currentHighestBidYER: number;
  currentHighestBidderId?: string;
  currentHighestBidderName?: string;
  totalBids: number;
  status: AuctionStatus;
  startAt: Date;
  endAt: Date;
  createdAt: Date;
  updatedAt: Date;
  winnerId?: string;
  winnerName?: string;
  winningBidYER?: number;
}

export interface Bid {
  id: string;
  auctionId: string;
  bidderId: string;
  bidderName: string;
  amountYER: number;
  createdAt: Date;
  status: 'VALID' | 'INVALID' | 'OUTBID';
}

export class AuctionService {
  private auctions: Map<string, Auction> = new Map();
  private bids: Map<string, Bid[]> = new Map();
  private readonly DEFAULT_MIN_BID = 50000; // 50,000 YER
  private locks: Set<string> = new Set(); // لمنع Race Conditions

  async createAuction(params: {
    vehicleId: string;
    vehicleData: any;
    sellerId: string;
    sellerName: string;
    minimumBidYER?: number;
    durationHours?: number;
    createdBy: string;
  }): Promise<Auction> {
    const minBid = params.minimumBidYER || this.DEFAULT_MIN_BID;
    
    if (minBid < this.DEFAULT_MIN_BID) {
      throw new Error(`Minimum bid cannot be less than ${this.DEFAULT_MIN_BID} YER - Configurable by OWNER/SUPER_ADMIN`);
    }

    // منع إدخال مركبة محجوزة في مزاد - تحقق Vehicle Lock
    // في الإنتاج: await vehicleLockService.canSellVehicle(params.vehicleId, params.sellerId)

    const auction: Auction = {
      id: `AUCTION-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      vehicleId: params.vehicleId,
      vehicleData: params.vehicleData,
      sellerId: params.sellerId,
      sellerName: params.sellerName,
      minimumBidYER: minBid,
      currentHighestBidYER: minBid,
      totalBids: 0,
      status: 'ACTIVE',
      startAt: new Date(),
      endAt: new Date(Date.now() + (params.durationHours || 24) * 60 * 60 * 1000),
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    this.auctions.set(auction.id, auction);
    this.bids.set(auction.id, []);

    console.log(`[AUCTION] Created auction ${auction.id} for vehicle ${params.vehicleId} - Min bid: ${minBid} YER`);

    return auction;
  }

  // مزايدة مع منع Race Conditions
  async placeBid(params: {
    auctionId: string;
    bidderId: string;
    bidderName: string;
    amountYER: number;
  }): Promise<{ success: boolean; bid: Bid; auction: Auction; message: string }> {
    const lockKey = `auction-${params.auctionId}`;
    
    // منع Race Condition - Lock
    if (this.locks.has(lockKey)) {
      throw new Error('Auction is being updated - Please try again - Race condition prevented');
    }

    this.locks.add(lockKey);

    try {
      const auction = this.auctions.get(params.auctionId);
      if (!auction) throw new Error('Auction not found');

      if (auction.status !== 'ACTIVE') {
        throw new Error(`Auction not active - Status: ${auction.status}`);
      }

      if (new Date() > auction.endAt) {
        auction.status = 'ENDED';
        this.auctions.set(auction.id, auction);
        throw new Error('Auction ended - Cannot bid after end time');
      }

      if (params.amountYER <= auction.currentHighestBidYER) {
        throw new Error(`Bid must be higher than current highest: ${auction.currentHighestBidYER} YER`);
      }

      if (params.amountYER < auction.minimumBidYER) {
        throw new Error(`Bid cannot be less than minimum: ${auction.minimumBidYER} YER`);
      }

      const bid: Bid = {
        id: `BID-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
        auctionId: params.auctionId,
        bidderId: params.bidderId,
        bidderName: params.bidderName,
        amountYER: params.amountYER,
        createdAt: new Date(),
        status: 'VALID',
      };

      // تحديث المزاد
      const bids = this.bids.get(params.auctionId) || [];
      
      // تحديث حالة المزايدات السابقة إلى OUTBID
      bids.forEach(b => {
        if (b.status === 'VALID') b.status = 'OUTBID';
      });

      bids.push(bid);
      this.bids.set(params.auctionId, bids);

      auction.currentHighestBidYER = params.amountYER;
      auction.currentHighestBidderId = params.bidderId;
      auction.currentHighestBidderName = params.bidderName;
      auction.totalBids = bids.length;
      auction.updatedAt = new Date();

      this.auctions.set(auction.id, auction);

      console.log(`[AUCTION] New bid ${bid.id} - ${params.amountYER} YER by ${params.bidderName} for auction ${params.auctionId}`);

      return {
        success: true,
        bid,
        auction,
        message: `تمت المزايدة بنجاح - ${params.amountYER.toLocaleString()} YER`,
      };

    } finally {
      this.locks.delete(lockKey);
    }
  }

  async endAuction(auctionId: string, endedBy: string): Promise<Auction> {
    const auction = this.auctions.get(auctionId);
    if (!auction) throw new Error('Auction not found');

    if (auction.status !== 'ACTIVE') {
      throw new Error('Auction not active');
    }

    auction.status = 'ENDED';
    auction.winnerId = auction.currentHighestBidderId;
    auction.winnerName = auction.currentHighestBidderName;
    auction.winningBidYER = auction.currentHighestBidYER;
    auction.updatedAt = new Date();

    this.auctions.set(auction.id, auction);

    // بعد انتهاء المزاد: حجز المركبة للفائز + مسار دفع
    if (auction.winnerId) {
      console.log(`[AUCTION] Auction ${auctionId} ended - Winner: ${auction.winnerName} - ${auction.winningBidYER} YER`);
      // في الإنتاج: إنشاء عملية بيع + Vehicle Lock + إشعار للفائز
    }

    return auction;
  }

  getAuction(id: string): Auction | undefined {
    return this.auctions.get(id);
  }

  getBids(auctionId: string): Bid[] {
    return this.bids.get(auctionId) || [];
  }

  getActiveAuctions(): Auction[] {
    return Array.from(this.auctions.values()).filter(a => a.status === 'ACTIVE');
  }

  // للاختبار - محاكاة عدد كبير من المزايدين
  async stressTest(auctionId: string, numBids: number): Promise<void> {
    console.log(`[AUCTION STRESS TEST] Starting ${numBids} concurrent bids for ${auctionId}`);
    
    const promises = [];
    for (let i = 0; i < numBids; i++) {
      promises.push(
        this.placeBid({
          auctionId,
          bidderId: `BIDDER-${i}`,
          bidderName: `مزايد ${i}`,
          amountYER: 50000 + i * 1000 + Math.floor(Math.random() * 5000),
        }).catch(e => console.log(`Bid ${i} failed: ${e.message}`))
      );
    }

    await Promise.all(promises);
    console.log(`[AUCTION STRESS TEST] Completed - Auction now has ${this.getBids(auctionId).length} bids`);
  }
}

export const auctionService = new AuctionService();
