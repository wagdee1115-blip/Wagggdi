
// lib/vehicle-lock.ts - Vehicle Lock System - منع البيع المزدوج - مركبات V11

export type VehicleLockReason = 
  | 'SALE_PENDING_BUYER'
  | 'BUYER_APPROVED'
  | 'PAYMENT_PENDING'
  | 'PAYMENT_PROCESSING'
  | 'PAYMENT_CONFIRMED'
  | 'ESCROW_HELD'
  | 'TRANSFER_IN_PROGRESS'
  | 'TRANSFER_PENDING'
  | 'OWNERSHIP_TRANSFERRED'
  | 'PAYOUT_PROTECTION'
  | 'PAYOUT_PROCESSING'
  | 'PAYOUT_PENDING'
  | 'RELEASE_FAILED'
  | 'MANUAL_REVIEW_REQUIRED'
  | 'AUCTION_ACTIVE';

export interface VehicleLock {
  id: string;
  vehicleId: string;
  lockedByOperationId: string; // Sale ID or Auction ID
  lockedByUserId: string;
  reason: VehicleLockReason;
  lockedAt: Date;
  expiresAt?: Date; // للـ EXPIRED بعد ساعتين
  releasedAt?: Date;
  status: 'ACTIVE' | 'RELEASED' | 'EXPIRED';
}

export class VehicleLockService {
  private locks: Map<string, VehicleLock> = new Map();
  private vehicleLocks: Map<string, string> = new Map(); // vehicleId -> lockId

  // قفل المركبة - Backend + Database level
  async lockVehicle(params: {
    vehicleId: string;
    operationId: string;
    userId: string;
    reason: VehicleLockReason;
    expiresAt?: Date;
  }): Promise<VehicleLock> {
    // منع Race Condition - تحقق إذا المركبة مقفلة
    const existingLockId = this.vehicleLocks.get(params.vehicleId);
    if (existingLockId) {
      const existingLock = this.locks.get(existingLockId);
      if (existingLock && existingLock.status === 'ACTIVE') {
        // تحقق إذا منتهي
        if (existingLock.expiresAt && new Date() > existingLock.expiresAt) {
          await this.releaseLock(params.vehicleId, 'SYSTEM', 'Lock expired');
        } else {
          throw new Error(`Vehicle ${params.vehicleId} already locked by operation ${existingLock.lockedByOperationId} - Reason: ${existingLock.reason} - Cannot double sale`);
        }
      }
    }

    const lock: VehicleLock = {
      id: `LOCK-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      vehicleId: params.vehicleId,
      lockedByOperationId: params.operationId,
      lockedByUserId: params.userId,
      reason: params.reason,
      lockedAt: new Date(),
      expiresAt: params.expiresAt,
      status: 'ACTIVE',
    };

    this.locks.set(lock.id, lock);
    this.vehicleLocks.set(params.vehicleId, lock.id);

    console.log(`[VEHICLE LOCK] Locked vehicle ${params.vehicleId} for operation ${params.operationId} - Reason: ${params.reason}`);

    return lock;
  }

  // تحقق إذا المركبة مقفلة
  async isVehicleLocked(vehicleId: string): Promise<{ locked: boolean; lock?: VehicleLock }> {
    const lockId = this.vehicleLocks.get(vehicleId);
    if (!lockId) return { locked: false };

    const lock = this.locks.get(lockId);
    if (!lock) return { locked: false };

    if (lock.status !== 'ACTIVE') return { locked: false };

    if (lock.expiresAt && new Date() > lock.expiresAt) {
      await this.releaseLock(vehicleId, 'SYSTEM', 'Lock expired - 2 hours timeout');
      return { locked: false };
    }

    return { locked: true, lock };
  }

  // تحرير المركبة
  async releaseLock(vehicleId: string, releasedBy: string, reason: string): Promise<void> {
    const lockId = this.vehicleLocks.get(vehicleId);
    if (!lockId) return;

    const lock = this.locks.get(lockId);
    if (!lock) return;

    lock.status = 'RELEASED';
    lock.releasedAt = new Date();
    
    this.locks.set(lockId, lock);
    this.vehicleLocks.delete(vehicleId);

    console.log(`[VEHICLE LOCK] Released vehicle ${vehicleId} - By: ${releasedBy} - Reason: ${reason}`);
  }

  // تحرير عند حالات معينة
  async releaseOnStatus(vehicleId: string, status: string, releasedBy: string): Promise<void> {
    const releasableStatuses = ['CANCELLED', 'REJECTED', 'EXPIRED', 'REFUNDED'];
    
    if (releasableStatuses.includes(status)) {
      await this.releaseLock(vehicleId, releasedBy, `Status: ${status} - Auto release`);
    }
    // لا تحرر عند COMPLETED لأن الملكية انتقلت للمشتري
  }

  // تحقق من صلاحية بيع مركبة - منع بيع محجوزة
  async canSellVehicle(vehicleId: string, sellerId: string): Promise<{ canSell: boolean; reason?: string }> {
    const { locked, lock } = await this.isVehicleLocked(vehicleId);
    
    if (locked && lock) {
      return {
        canSell: false,
        reason: `Vehicle is locked - Operation: ${lock.lockedByOperationId} - Reason: ${lock.reason} - Cannot create second sale or auction`,
      };
    }

    // تحقق إضافي: هل المركبة مملوكة للبائع؟
    // في الإنتاج: query Vehicle table where ownerId == sellerId
    // هنا Mock

    return { canSell: true };
  }

  getLock(vehicleId: string): VehicleLock | undefined {
    const lockId = this.vehicleLocks.get(vehicleId);
    if (!lockId) return undefined;
    return this.locks.get(lockId);
  }

  getAllActiveLocks(): VehicleLock[] {
    return Array.from(this.locks.values()).filter(l => l.status === 'ACTIVE');
  }
}

export const vehicleLockService = new VehicleLockService();
