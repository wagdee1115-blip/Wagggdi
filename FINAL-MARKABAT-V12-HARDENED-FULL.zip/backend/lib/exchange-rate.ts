
// lib/exchange-rate.ts - نظام سعر الصرف - مركبات

export type ExchangeRateSource = 'MANUAL' | 'BANK_API' | 'EXTERNAL_PROVIDER';

export interface ExchangeRate {
  id: string;
  usdToYer: number; // مثلا 535
  source: ExchangeRateSource;
  isAutoUpdateEnabled: boolean;
  updatedBy: string; // userId
  updatedByName: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface ExchangeRateHistory {
  id: string;
  oldRate: number;
  newRate: number;
  changedBy: string;
  changedByName: string;
  reason?: string;
  createdAt: Date;
}

export class ExchangeRateProvider {
  private currentRate: ExchangeRate;
  private history: ExchangeRateHistory[] = [];

  constructor() {
    // سعر افتراضي
    this.currentRate = {
      id: 'EXRATE-001',
      usdToYer: 535,
      source: 'MANUAL',
      isAutoUpdateEnabled: false,
      updatedBy: 'OWNER',
      updatedByName: 'وجدي عصام سعيد عبده مزاحم',
      createdAt: new Date(),
      updatedAt: new Date(),
    };
  }

  // الحصول على السعر الحالي
  getCurrentRate(): ExchangeRate {
    return { ...this.currentRate };
  }

  // تحديث السعر يدويا - فقط OWNER/SUPER_ADMIN
  async updateRate(params: {
    newRate: number;
    updatedBy: string;
    updatedByName: string;
    reason?: string;
    source?: ExchangeRateSource;
  }): Promise<{ oldRate: ExchangeRate; newRate: ExchangeRate; history: ExchangeRateHistory }> {
    const oldRate = { ...this.currentRate };

    if (params.newRate <= 0) {
      throw new Error('Exchange rate must be positive');
    }

    const historyEntry: ExchangeRateHistory = {
      id: `EXHIST-${Date.now()}`,
      oldRate: oldRate.usdToYer,
      newRate: params.newRate,
      changedBy: params.updatedBy,
      changedByName: params.updatedByName,
      reason: params.reason,
      createdAt: new Date(),
    };

    this.currentRate = {
      ...this.currentRate,
      usdToYer: params.newRate,
      source: params.source || 'MANUAL',
      updatedBy: params.updatedBy,
      updatedByName: params.updatedByName,
      updatedAt: new Date(),
    };

    this.history.push(historyEntry);

    return {
      oldRate,
      newRate: { ...this.currentRate },
      history: historyEntry,
    };
  }

  // تفعيل/إيقاف التحديث التلقائي
  async setAutoUpdate(enabled: boolean, updatedBy: string, updatedByName: string): Promise<ExchangeRate> {
    this.currentRate.isAutoUpdateEnabled = enabled;
    this.currentRate.updatedBy = updatedBy;
    this.currentRate.updatedByName = updatedByName;
    this.currentRate.updatedAt = new Date();
    return { ...this.currentRate };
  }

  // حساب رسوم المنصة بالريال
  calculatePlatformFeeYER(platformFeeUSD: number = 80): number {
    return platformFeeUSD * this.currentRate.usdToYer;
  }

  // تثبيت السعر في العملية - مهم: لا يتغير بعد إنشاء العملية
  freezeRateForOperation(): number {
    return this.currentRate.usdToYer;
  }

  getHistory(): ExchangeRateHistory[] {
    return [...this.history].sort((a,b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  // للربط المستقبلي مع API بنك
  async fetchFromBankAPI(): Promise<number> {
    // حاليا Mock - مستقبلا يربط مع API بنك الكريمي أو مصدر رسمي
    // لا نخترع API الآن
    throw new Error('Bank API integration not yet configured - Use MANUAL mode. Ready for future integration.');
  }

  async fetchFromExternalProvider(): Promise<number> {
    throw new Error('External provider not configured - Ready for future integration.');
  }
}

export const exchangeRateProvider = new ExchangeRateProvider();
