
// lib/exchange-rate-manager.ts - إدارة سعر الصرف مع حماية OTP - مركبات V11

import { ExchangeRateProvider, ExchangeRate } from './exchange-rate';
import { OtpService } from './otp';

export interface ExchangeRateChangeRequest {
  id: string;
  oldRate: number;
  newRate: number;
  requestedBy: string;
  requestedByName: string;
  reason: string;
  ipAddress?: string;
  sessionId?: string;
  otpId?: string;
  otpVerified: boolean;
  status: 'PENDING_OTP' | 'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED';
  createdAt: Date;
  approvedAt?: Date;
  approvedBy?: string;
}

export class ExchangeRateManager {
  private provider: ExchangeRateProvider;
  private otpService: OtpService;
  private changeRequests: Map<string, ExchangeRateChangeRequest> = new Map();
  private history: any[] = [];

  constructor(provider?: ExchangeRateProvider, otpService?: OtpService) {
    this.provider = provider || new ExchangeRateProvider();
    this.otpService = otpService || new OtpService();
  }

  // طلب تغيير سعر الصرف - يتطلب OTP
  async requestRateChange(params: {
    newRate: number;
    requestedBy: string;
    requestedByName: string;
    requestedByRole: string;
    reason: string;
    ipAddress?: string;
    sessionId?: string;
  }): Promise<{ requestId: string; otpId: string; expiresAt: Date; message: string }> {
    // فقط OWNER/SUPER_ADMIN
    if (params.requestedByRole !== 'OWNER' && params.requestedByRole !== 'SUPER_ADMIN') {
      throw new Error('Only OWNER/SUPER_ADMIN can change exchange rate');
    }

    if (params.newRate <= 0) {
      throw new Error('Exchange rate must be positive');
    }

    const currentRate = this.provider.getCurrentRate();

    const request: ExchangeRateChangeRequest = {
      id: `EXCHANGE-REQ-${Date.now()}`,
      oldRate: currentRate.usdToYer,
      newRate: params.newRate,
      requestedBy: params.requestedBy,
      requestedByName: params.requestedByName,
      reason: params.reason,
      ipAddress: params.ipAddress,
      sessionId: params.sessionId,
      otpVerified: false,
      status: 'PENDING_OTP',
      createdAt: new Date(),
    };

    this.changeRequests.set(request.id, request);

    // إرسال OTP للتأكيد
    const otpResult = await this.otpService.sendOtp({
      phone: 'OWNER_PHONE', // في الإنتاج: رقم OWNER
      operationId: request.id,
      type: 'SELLER', // استخدام نوع موجود
    });

    request.otpId = otpResult.otpId;
    this.changeRequests.set(request.id, request);

    console.log(`[EXCHANGE RATE] Change requested: ${currentRate.usdToYer} -> ${params.newRate} by ${params.requestedByName} - OTP sent`);

    return {
      requestId: request.id,
      otpId: otpResult.otpId,
      expiresAt: otpResult.expiresAt,
      message: 'OTP sent to OWNER for exchange rate change confirmation',
    };
  }

  // تأكيد تغيير سعر الصرف بـ OTP
  async confirmRateChangeWithOtp(params: {
    requestId: string;
    otpId: string;
    otp: string;
    confirmedBy: string;
    confirmedByName: string;
  }): Promise<{ oldRate: number; newRate: number; history: any }> {
    const request = this.changeRequests.get(params.requestId);
    if (!request) throw new Error('Change request not found');

    if (request.status !== 'PENDING_OTP') {
      throw new Error('Request not pending OTP');
    }

    // تحقق OTP
    const verification = await this.otpService.verifyOtp({
      otpId: params.otpId,
      otp: params.otp,
      operationId: request.id,
      type: 'SELLER',
    });

    if (!verification.verified) {
      throw new Error('OTP verification failed');
    }

    request.otpVerified = true;
    request.status = 'APPROVED';
    request.approvedAt = new Date();
    request.approvedBy = params.confirmedBy;

    // تحديث السعر الفعلي
    const result = await this.provider.updateRate({
      newRate: request.newRate,
      updatedBy: params.confirmedBy,
      updatedByName: params.confirmedByName,
      reason: request.reason,
      source: 'MANUAL',
    });

    // تسجيل في التاريخ مع IP/Session
    this.history.push({
      id: `HIST-${Date.now()}`,
      oldRate: request.oldRate,
      newRate: request.newRate,
      changedBy: params.confirmedBy,
      changedByName: params.confirmedByName,
      reason: request.reason,
      ipAddress: request.ipAddress,
      sessionId: request.sessionId,
      timestamp: new Date(),
    });

    this.changeRequests.set(request.id, request);

    console.log(`[EXCHANGE RATE] Changed: ${request.oldRate} -> ${request.newRate} by ${params.confirmedByName}`);

    return {
      oldRate: result.oldRate.usdToYer,
      newRate: result.newRate.usdToYer,
      history: result.history,
    };
  }

  getCurrentRate(): ExchangeRate {
    return this.provider.getCurrentRate();
  }

  getHistory(): any[] {
    return [...this.history].sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  getPendingRequests(): ExchangeRateChangeRequest[] {
    return Array.from(this.changeRequests.values()).filter(r => r.status === 'PENDING_OTP' || r.status === 'PENDING_APPROVAL');
  }

  // تثبيت سعر الصرف للعملية - Snapshot
  freezeRateForOperation(operationId: string): { rate: number; rateId: string; snapshotAt: Date } {
    const current = this.provider.getCurrentRate();
    return {
      rate: current.usdToYer,
      rateId: current.id,
      snapshotAt: new Date(),
    };
  }
}

export const exchangeRateManager = new ExchangeRateManager();
