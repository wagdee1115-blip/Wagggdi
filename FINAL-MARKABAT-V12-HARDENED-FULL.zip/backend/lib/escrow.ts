
// lib/escrow.ts - نظام الوسيط المالي - مركبات
// IMPORTANT: الرصيد الحالي 16,280$ HELD يجب أن يبقى كما هو ولا يتم المساس به إلا بعملية حقيقية
// هذا الملف يضيف طبقة جديدة فوق MockPaymentProvider الموجود بدون كسره

import { MockPaymentProvider, PaymentProvider } from './providers/payment';

export interface EscrowAccount {
  id: string;
  totalHeldUSD: number; // الرصيد الحالي 16,280$ - لا يمس إلا بعملية حقيقية
  totalHeldYER: number;
  currency: string;
  status: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface EscrowTransaction {
  id: string;
  vehicleSaleId: string;
  vehicleAmountYER: number; // قيمة المركبة بالريال اليمني - يحددها البائع
  platformFeeUSD: number; // 80 USD
  platformFeeYER: number; // 80 * exchangeRate
  governmentFeesYER: number; // 0 حاليا
  totalPaidYER: number; // vehicleAmount + platformFee + governmentFees
  sellerPayoutYER: number; // = vehicleAmount فقط
  platformRevenueYER: number; // = platformFeeYER
  exchangeRate: number; // سعر الصرف المثبت وقت العملية
  status: 'HELD' | 'PENDING_VERIFICATION' | 'VERIFIED' | 'SECURED' | 'RELEASE_PENDING' | 'RELEASE_READY' | 'RELEASE_PROCESSING' | 'RELEASED' | 'RELEASE_FAILED' | 'REFUNDED';
  paymentProviderReference?: string;
  createdAt: Date;
  securedAt?: Date;
  releaseReadyAt?: Date; // +15 دقيقة من نجاح نقل الملكية
}

// الرصيد الحالي الموجود - لا يمس
export const CURRENT_ESCROW_BALANCE: EscrowAccount = {
  id: 'ESCROW-MAIN-001',
  totalHeldUSD: 16280, // 16,280$ HELD - موجود حاليا - لا يمس
  totalHeldYER: 0, // يحسب حسب سعر الصرف الحالي
  currency: 'USD',
  status: 'HELD',
  createdAt: new Date('2026-01-01'),
  updatedAt: new Date(),
};

export class EscrowService {
  private paymentProvider: PaymentProvider;
  private transactions: Map<string, EscrowTransaction> = new Map();

  constructor(paymentProvider?: PaymentProvider) {
    this.paymentProvider = paymentProvider || new MockPaymentProvider();
  }

  // إنشاء عملية وسيط جديدة - لا تمس الرصيد القديم إلا بعد تأكيد حقيقي
  async createEscrowTransaction(params: {
    vehicleSaleId: string;
    vehicleAmountYER: number;
    platformFeeUSD: number;
    exchangeRate: number;
    governmentFeesYER?: number;
  }): Promise<EscrowTransaction> {
    const governmentFeesYER = params.governmentFeesYER || 0;
    const platformFeeYER = params.platformFeeUSD * params.exchangeRate;
    const totalPaidYER = params.vehicleAmountYER + platformFeeYER + governmentFeesYER;

    const transaction: EscrowTransaction = {
      id: `ESCROW-TX-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      vehicleSaleId: params.vehicleSaleId,
      vehicleAmountYER: params.vehicleAmountYER,
      platformFeeUSD: params.platformFeeUSD,
      platformFeeYER,
      governmentFeesYER,
      totalPaidYER,
      sellerPayoutYER: params.vehicleAmountYER, // البائع يستلم قيمة المركبة فقط
      platformRevenueYER: platformFeeYER,
      exchangeRate: params.exchangeRate,
      status: 'HELD',
      createdAt: new Date(),
    };

    this.transactions.set(transaction.id, transaction);
    return transaction;
  }

  // تأمين الأموال - يأتي بعد PAYMENT_VERIFIED
  async secureFunds(transactionId: string): Promise<EscrowTransaction> {
    const tx = this.transactions.get(transactionId);
    if (!tx) throw new Error('Escrow transaction not found');

    // هنا فقط نضيف للرصيد الحقيقي - بعد تأكيد Admin
    // لكن نحافظ على الرصيد القديم 16,280$ كما هو - نضيف فوقه فقط عند عملية حقيقية
    tx.status = 'SECURED';
    tx.securedAt = new Date();
    this.transactions.set(transactionId, tx);

    return tx;
  }

  // بدء فترة الحماية 15 دقيقة بعد نجاح نقل الملكية
  async startReleaseProtection(transactionId: string): Promise<EscrowTransaction> {
    const tx = this.transactions.get(transactionId);
    if (!tx) throw new Error('Escrow transaction not found');

    tx.status = 'RELEASE_PENDING';
    tx.releaseReadyAt = new Date(Date.now() + 15 * 60 * 1000); // +15 دقيقة
    this.transactions.set(transactionId, tx);

    return tx;
  }

  // تحويل للبائع بعد 15 دقيقة - قيمة المركبة فقط
  async releaseToSeller(transactionId: string): Promise<EscrowTransaction> {
    const tx = this.transactions.get(transactionId);
    if (!tx) throw new Error('Escrow transaction not found');

    if (tx.status !== 'RELEASE_PENDING' && tx.status !== 'RELEASE_READY') {
      throw new Error('Transaction not ready for release');
    }

    // تحقق من مرور 15 دقيقة
    if (tx.releaseReadyAt && new Date() < tx.releaseReadyAt) {
      throw new Error('Release protection period not ended - 15 minutes required');
    }

    tx.status = 'RELEASE_PROCESSING';
    this.transactions.set(transactionId, tx);

    try {
      // محاكاة التحويل - في الحقيقة هنا يتم الربط مع مزود بنكي
      const result = await this.paymentProvider.releasePayment(tx.id);
      
      if (result.status === 'SUCCESS') {
        tx.status = 'RELEASED';
      } else {
        tx.status = 'RELEASE_FAILED';
        throw new Error('Failed to release funds to seller');
      }
    } catch (error) {
      tx.status = 'RELEASE_FAILED';
      this.transactions.set(transactionId, tx);
      throw error;
    }

    this.transactions.set(transactionId, tx);
    return tx;
  }

  // فشل التحويل - إبقاء الأموال محمية
  async markReleaseFailed(transactionId: string, reason: string): Promise<void> {
    const tx = this.transactions.get(transactionId);
    if (tx) {
      tx.status = 'RELEASE_FAILED';
      this.transactions.set(transactionId, tx);
      // إشعار الإدارة + إبقاء الأموال محمية
      console.error(`Escrow release failed for ${transactionId}: ${reason} - Funds remain protected`);
    }
  }

  getTransaction(id: string): EscrowTransaction | undefined {
    return this.transactions.get(id);
  }

  getCurrentBalance(): EscrowAccount {
    // إرجاع الرصيد الحالي 16,280$ + أي عمليات حقيقية جديدة مؤمنة
    // حاليا نرجع الثابت - في المستقبل يحسب من DB
    return { ...CURRENT_ESCROW_BALANCE };
  }

  // للاختبار فقط - حساب مثال
  static calculateExample() {
    const vehicleAmount = 10000000; // 10,000,000 YER
    const exchangeRate = 535;
    const platformFeeUSD = 80;
    const platformFeeYER = platformFeeUSD * exchangeRate; // 42,800
    const total = vehicleAmount + platformFeeYER; // 10,042,800
    return {
      vehicleAmount,
      exchangeRate,
      platformFeeUSD,
      platformFeeYER,
      governmentFees: 0,
      totalPaid: total,
      sellerPayout: vehicleAmount, // البائع يستلم 10,000,000 فقط
      platformRevenue: platformFeeYER, // المنصة تحتفظ 42,800
    };
  }
}

export const escrowService = new EscrowService();
