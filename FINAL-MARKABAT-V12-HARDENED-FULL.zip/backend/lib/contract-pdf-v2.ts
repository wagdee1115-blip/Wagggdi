
// lib/contract-pdf-v2.ts - عقد البيع مع QR + Hash + Versioning - مركبات V11
import { createHash } from 'crypto';
export interface ContractVersion { version: number; contractData: any; hash: string; previousHash?: string; createdAt: Date; createdBy: string; reason?: string; }
export interface ContractDocument { id: string; contractNumber: string; operationId: string; currentVersion: number; versions: ContractVersion[]; verificationId: string; verificationUrl: string; qrCodeData: string; status: string; createdAt: Date; updatedAt: Date; }
export class ContractService {
  private contracts: Map<string, ContractDocument> = new Map();
  private generateHash(data: any): string { return createHash('sha256').update(JSON.stringify(data)).digest('hex'); }
  async createContract(params: { operationId: string; contractData: any; createdBy: string; }): Promise<ContractDocument> {
    const contractNumber = `MRK-CONTRACT-${new Date().getFullYear()}-${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
    const verificationId = `VERIFY-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
    const hash = this.generateHash(params.contractData);
    const version: ContractVersion = { version: 1, contractData: params.contractData, hash, createdAt: new Date(), createdBy: params.createdBy };
    const contract: ContractDocument = { id: `CONTRACT-${Date.now()}`, contractNumber, operationId: params.operationId, currentVersion: 1, versions: [version], verificationId, verificationUrl: `https://markabat.ye/verify/contract/${verificationId}`, qrCodeData: JSON.stringify({ verificationId, contractNumber, hash }), status: 'ISSUED', createdAt: new Date(), updatedAt: new Date() };
    this.contracts.set(contract.id, contract);
    return contract;
  }
  verifyContract(verificationId: string): { valid: boolean; contract?: ContractDocument; message: string } {
    const contract = Array.from(this.contracts.values()).find(c => c.verificationId === verificationId);
    if (!contract) return { valid: false, message: 'Contract not found' };
    return { valid: true, contract, message: `Valid - ${contract.contractNumber} - V${contract.currentVersion}` };
  }
  getContract(id: string): ContractDocument | undefined { return this.contracts.get(id); }
}
export const contractService = new ContractService();
