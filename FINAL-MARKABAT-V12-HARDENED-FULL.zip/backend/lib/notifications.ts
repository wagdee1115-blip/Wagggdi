
// lib/notifications.ts - نظام الإشعارات - مركبات V11 - In-App + SMS

export type NotificationPriority = 'LOW' | 'NORMAL' | 'HIGH' | 'CRITICAL';
export type NotificationChannel = 'IN_APP' | 'SMS' | 'PUSH' | 'EMAIL' | 'WHATSAPP';
export type NotificationType = 
  | 'TRANSFER_REQUEST' | 'BUYER_APPROVAL' | 'PAYMENT_CONFIRMED' | 'ESCROW_HELD'
  | 'SELLER_OTP' | 'OWNERSHIP_TRANSFERRED' | 'PAYOUT_PROTECTION' | 'PAYOUT_CONFIRMED'
  | 'REFUND' | 'SECURITY_ALERT' | 'NEW_LOGIN' | 'AUCTION_WIN' | 'ADVERTISEMENT';

export interface Notification {
  id: string;
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  priority: NotificationPriority;
  channels: NotificationChannel[];
  operationId?: string;
  data?: any;
  read: boolean;
  sentAt: Date;
  readAt?: Date;
  smsSent?: boolean;
  smsReference?: string;
}

export interface SMSProvider {
  name: string;
  sendSMS(phone: string, message: string, operationId?: string): Promise<{ sent: boolean; reference: string; provider: string }>;
}

export class MockSMSProvider implements SMSProvider {
  name = 'MOCK_SMS';
  
  async sendSMS(phone: string, message: string, operationId?: string) {
    // لا ترسل بيانات مالية حساسة كاملة في SMS
    const sanitizedMessage = this.sanitizeMessage(message);
    
    console.log(`[MOCK SMS - ${phone} - Op:${operationId}]: ${sanitizedMessage} - Mock - لا يوجد ربط حقيقي حاليا - +967 مدعوم مستقبلا`);
    
    return {
      sent: true,
      reference: `MOCK-SMS-${Date.now()}`,
      provider: 'MOCK_SMS',
    };
  }

  private sanitizeMessage(message: string): string {
    // لا ترسل مبلغ كامل أو بيانات حساسة
    // مثال: "تم تأمين مبلغ 10,000,000 YER" -> "تم تأمين مبلغ المركبة"
    // هنا Mock يسمح بالتفاصيل لكن في Production يجب تقليل التفاصيل
    if (process.env.NODE_ENV === 'production') {
      // في الإنتاج: لا ترسل مبلغ دقيق
      return message.replace(/\d{1,3}(,\d{3})* YER/g, 'المبلغ المتفق عليه');
    }
    return message;
  }
}

export class RealSMSProvider implements SMSProvider {
  name = 'REAL_SMS_YEMEN';
  
  async sendSMS(phone: string, message: string, operationId?: string) {
    // جاهز للربط مع مزود يمني يدعم +967
    // مثل: Yemen Mobile, Sabafon, YOU, Y Telecom
    
    if (!phone.startsWith('+967') && !phone.startsWith('967') && !phone.startsWith('7')) {
      throw new Error('Only Yemeni numbers supported - +967 - رقم يمني فقط');
    }

    throw new Error('Real SMS provider not configured - Ready for integration with Yemeni provider supporting +967. Use Mock in dev.');
  }
}

export class NotificationService {
  private notifications: Map<string, Notification[]> = new Map(); // userId -> notifications
  private smsProvider: SMSProvider;

  constructor(smsProvider?: SMSProvider) {
    this.smsProvider = smsProvider || new MockSMSProvider();
  }

  async sendNotification(params: {
    userId: string;
    type: NotificationType;
    title: string;
    message: string;
    priority?: NotificationPriority;
    channels?: NotificationChannel[];
    operationId?: string;
    data?: any;
    phone?: string; // للـ SMS
  }): Promise<Notification> {
    const notification: Notification = {
      id: `NOTIF-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      userId: params.userId,
      type: params.type,
      title: params.title,
      message: params.message,
      priority: params.priority || 'NORMAL',
      channels: params.channels || ['IN_APP'],
      operationId: params.operationId,
      data: params.data,
      read: false,
      sentAt: new Date(),
    };

    // حفظ In-App
    if (params.channels?.includes('IN_APP') || !params.channels) {
      const userNotifs = this.notifications.get(params.userId) || [];
      userNotifs.push(notification);
      this.notifications.set(params.userId, userNotifs);
    }

    // إرسال SMS للأحداث المهمة
    const importantTypes: NotificationType[] = [
      'TRANSFER_REQUEST', 'PAYMENT_CONFIRMED', 'ESCROW_HELD', 'SELLER_OTP',
      'OWNERSHIP_TRANSFERRED', 'PAYOUT_CONFIRMED', 'REFUND', 'SECURITY_ALERT'
    ];

    if (importantTypes.includes(params.type) && params.phone) {
      try {
        const smsResult = await this.smsProvider.sendSMS(params.phone, `${params.title}: ${params.message}`, params.operationId);
        notification.smsSent = smsResult.sent;
        notification.smsReference = smsResult.reference;
      } catch (error) {
        console.error(`Failed to send SMS to ${params.phone}:`, error);
        notification.smsSent = false;
      }
    }

    console.log(`[NOTIFICATION] ${params.type} to ${params.userId} - ${params.title} - Priority: ${notification.priority}`);

    return notification;
  }

  // إشعارات محددة حسب المواصفات
  async notifyBuyerTransferRequest(buyerId: string, buyerPhone: string, sellerName: string, vehicleData: any, operationId: string): Promise<Notification> {
    return await this.sendNotification({
      userId: buyerId,
      type: 'TRANSFER_REQUEST',
      title: 'لديك طلب نقل ملكية مركبة',
      message: `من ${sellerName} - ${vehicleData.brand} ${vehicleData.model} - لوحة ${vehicleData.plateNumber}`,
      priority: 'HIGH',
      channels: ['IN_APP', 'SMS'],
      operationId,
      data: { vehicleData, sellerName },
      phone: buyerPhone,
    });
  }

  async notifySellerFundsSecured(sellerId: string, sellerPhone: string, amountYER: number, operationId: string): Promise<Notification> {
    return await this.sendNotification({
      userId: sellerId,
      type: 'ESCROW_HELD',
      title: 'تم تأمين قيمة المركبة لدى الوسيط',
      message: `تم إيداع مبلغ المركبة في حساب الوسيط، ويمكنك إكمال إجراءات نقل الملكية - العملية: ${operationId}`,
      priority: 'CRITICAL',
      channels: ['IN_APP', 'SMS'],
      operationId,
      phone: sellerPhone,
    });
  }

  async notifyOwnershipTransferred(userId: string, phone: string, plateNumber: string, operationId: string): Promise<Notification> {
    return await this.sendNotification({
      userId,
      type: 'OWNERSHIP_TRANSFERRED',
      title: 'تم نقل الملكية بنجاح',
      message: `تم نقل ملكية المركبة ${plateNumber} بنجاح - العملية: ${operationId}`,
      priority: 'CRITICAL',
      channels: ['IN_APP', 'SMS'],
      operationId,
      phone,
    });
  }

  getNotifications(userId: string, unreadOnly?: boolean): Notification[] {
    const notifs = this.notifications.get(userId) || [];
    if (unreadOnly) return notifs.filter(n => !n.read);
    return notifs.sort((a, b) => b.sentAt.getTime() - a.sentAt.getTime());
  }

  markAsRead(userId: string, notificationId: string): void {
    const notifs = this.notifications.get(userId) || [];
    const notif = notifs.find(n => n.id === notificationId);
    if (notif) {
      notif.read = true;
      notif.readAt = new Date();
    }
  }

  markAllAsRead(userId: string): void {
    const notifs = this.notifications.get(userId) || [];
    notifs.forEach(n => {
      if (!n.read) {
        n.read = true;
        n.readAt = new Date();
      }
    });
  }
}

export const notificationService = new NotificationService();
