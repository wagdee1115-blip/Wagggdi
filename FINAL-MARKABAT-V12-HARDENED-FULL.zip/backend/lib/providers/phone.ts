export interface PhoneProvider {
  name: string;
  sendOtp(phone: string): Promise<{ providerReference: string; expiresAt: Date }>;
  verifyOtp(phone: string, otp: string, reference: string): Promise<boolean>;
  verifyPhoneOwnership?(nationalId: string, phone: string): Promise<{ owned: boolean; message: string }>;
}

export class MockPhoneProvider implements PhoneProvider {
  name = 'MOCK_PHONE';
  private otps = new Map<string, string>();

  async sendOtp(phone: string) {
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    this.otps.set(phone, otp);
    console.log(`[MOCK OTP for ${phone}]: ${otp} - بيانات تجريبية`);
    return { providerReference: `MOCK-PHONE-${Date.now()}`, expiresAt: new Date(Date.now() + 5 * 60 * 1000) };
  }

  async verifyOtp(phone: string, otp: string): Promise<boolean> {
    return this.otps.get(phone) === otp;
  }

  async verifyPhoneOwnership(nationalId: string, phone: string) {
    // هذه العملية منفصلة وتحتاج مزود رسمي من شركات الاتصالات
    return {
      owned: false,
      message: 'التحقق من ملكية الرقم يتطلب ربط رسمي مع شركة الاتصالات - Mock حالياً لا يثبت الملكية.',
    };
  }
}
