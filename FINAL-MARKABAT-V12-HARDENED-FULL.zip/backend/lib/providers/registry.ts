// سجل مركزي لكل Providers - جاهز للاستبدال
import { MockIdentityProvider } from './identity';
import { MockPhoneProvider } from './phone';
import { MockVehicleVerificationProvider } from './vehicle';
import { MockPaymentProvider } from './payment';
import { MockBankProvider } from './bank';

export const providers = {
  identity: new MockIdentityProvider(),
  phone: new MockPhoneProvider(),
  vehicle: new MockVehicleVerificationProvider(),
  payment: new MockPaymentProvider(),
  bank: new MockBankProvider(),
  // insurance, inspection, violation, appointment -> نفس النمط
};

export const integrationStatuses = [
  { providerName: 'IDENTITY', providerType: 'IDENTITY', status: 'MOCK' },
  { providerName: 'PHONE', providerType: 'PHONE', status: 'MOCK' },
  { providerName: 'VEHICLE', providerType: 'VEHICLE', status: 'MOCK' },
  { providerName: 'INSURANCE', providerType: 'INSURANCE', status: 'MOCK' },
  { providerName: 'INSPECTION', providerType: 'INSPECTION', status: 'MOCK' },
  { providerName: 'VIOLATION', providerType: 'VIOLATION', status: 'MOCK' },
  { providerName: 'APPOINTMENT', providerType: 'APPOINTMENT', status: 'MOCK' },
  { providerName: 'BANK', providerType: 'BANK', status: 'MOCK' },
  { providerName: 'PAYMENT', providerType: 'PAYMENT', status: 'MOCK' },
] as const;
