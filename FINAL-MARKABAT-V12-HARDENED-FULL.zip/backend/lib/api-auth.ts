import { cookies } from 'next/headers';
import { db } from './db';
import { verifyJwt } from './auth';
import type { Role } from '@prisma/client';

export async function getCurrentUser() {
  const token = cookies().get('markabat_session')?.value;
  if (!token) return null;
  const payload = await verifyJwt(token);
  if (!payload?.sub) return null;
  return db.user.findUnique({ where: { id: String(payload.sub) } });
}

export async function requireUser() {
  const user = await getCurrentUser();
  if (!user || user.status !== 'ACTIVE') throw new Error('UNAUTHORIZED');
  return user;
}

export async function requireRole(roles: Role[]) {
  const user = await requireUser();
  if (!roles.includes(user.role)) throw new Error('FORBIDDEN');
  return user;
}

export function apiError(error: unknown) {
  const message = error instanceof Error ? error.message : 'Internal server error';
  const status = message === 'UNAUTHORIZED' ? 401 : message === 'FORBIDDEN' ? 403 : 400;
  return Response.json({ ok: false, error: message }, { status });
}
