
// lib/payment-provider.ts - طبقة PaymentProvider جاهزة للربط مع مزود يمني

export type PaymentMethod = 'BANK_TRANSFER' | 'MADA' | 'APPLE_PAY' | 'CASH' | 'WALLET';
export type PaymentVerificationStatus = 'PENDING_RECEIPT' | 'PENDING_VERIFICATION' | 'VERIFIED' | 'FAILED' | 'CANCELLED';

export interface PaymentReceipt {
  id: string;
  operationId: string;
  amountYER: number;
  method: PaymentMethod;
  receiptUrl?: string; // رابط الإيصال المرفوع
  receiptFileName?: string;
  uploadedAt: Date;
  uploadedBy: string;
  status: PaymentVerificationStatus;
  verifiedBy?: string;
  verifiedAt?: Date;
  verificationNotes?: string;
  bankReference?: string;
}

export interface EnhancedPaymentProvider {
  name: string;
  createPaymentRequest(amount: number, currency: string, operationId: string): Promise<{ reference: string; status: string; instructions: string }>;
  verifyPaymentByAdmin(reference: string, adminId: string, adminName: string): Promise<{ verified: boolean; status: PaymentVerificationStatus }>;
  // للربط المستقبلي
  connectRealProvider?(config: any): Promise<void>;
}

export class BankTransferWithReceiptProvider implements EnhancedPaymentProvider {
  name = 'BANK_TRANSFER_WITH_RECEIPT';
  private receipts: Map<string, PaymentReceipt> = new Map();

  async createPaymentRequest(amount: number, currency: string, operationId: string) {
    const reference = `BANK-REQ-${operationId}-${Date.now()}`;
    const instructions = `
      يرجى تحويل المبلغ ${amount} ${currency} إلى حساب الوسيط:
      البنك: [يتم تحديده بعد اعتماد مزود الدفع]
      رقم الحساب: [يتم إدخاله من إعدادات الخادم الآمنة]
      باسم: [الاسم القانوني للحساب الوسيط]
      المرجع: ${reference}
      ثم ارفع إيصال التحويل في النظام.
      تنبيه: رفع الإيصال وحده لا يعتبر دليلا على وصول المال - يجب تأكيد الإدارة.
    `;

    return { reference, status: 'WAITING_PAYMENT', instructions };
  }

  // رفع الإيصال - لا يعتبر دليلا على وصول المال
  async uploadReceipt(params: {
    operationId: string;
    amountYER: number;
    receiptUrl: string;
    receiptFileName: string;
    uploadedBy: string;
    method: PaymentMethod;
  }): Promise<PaymentReceipt> {
    const receipt: PaymentReceipt = {
      id: `RECEIPT-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      operationId: params.operationId,
      amountYER: params.amountYER,
      method: params.method,
      receiptUrl: params.receiptUrl,
      receiptFileName: params.receiptFileName,
      uploadedAt: new Date(),
      uploadedBy: params.uploadedBy,
      status: 'PAYMENT_PENDING_VERIFICATION', // يبقى حتى تأكيد Admin
    };

    this.receipts.set(receipt.id, receipt);
    return receipt;
  }

  // تأكيد وصول المبلغ بواسطة Admin/SUPER_ADMIN - فقط
  async verifyPaymentByAdmin(receiptId: string, adminId: string, adminName: string, bankReference?: string): Promise<{ verified: boolean; receipt: PaymentReceipt }> {
    const receipt = this.receipts.get(receiptId);
    if (!receipt) throw new Error('Receipt not found');

    // فقط Admin/SUPER_ADMIN يستطيع التأكيد - التحقق من الصلاحية يكون في الـ API layer
    receipt.status = 'VERIFIED';
    receipt.verifiedBy = adminId;
    receipt.verifiedAt = new Date();
    receipt.bankReference = bankReference;

    this.receipts.set(receiptId, receipt);

    return { verified: true, receipt };
  }

  async markPaymentVerified(operationId: string): Promise<PaymentReceipt | undefined> {
    // البحث عن إيصال العملية
    for (const receipt of this.receipts.values()) {
      if (receipt.operationId === operationId) {
        return receipt;
      }
    }
    return undefined;
  }

  getReceipt(id: string): PaymentReceipt | undefined {
    return this.receipts.get(id);
  }

  getReceiptsByOperation(operationId: string): PaymentReceipt[] {
    return Array.from(this.receipts.values()).filter(r => r.operationId === operationId);
  }

  // للربط المستقبلي مع مزود دفع يمني/API حقيقي
  async connectRealProvider(config: any): Promise<void> {
    // جاهز للربط بدون إعادة بناء النظام
    throw new Error('Real Yemeni payment provider integration ready - Configure with official provider API. Current: bank transfer with receipt + admin verification.');
  }
}

// طبقة PaymentProvider موحدة
export class PaymentProviderFactory {
  static createProvider(type: string = 'BANK_TRANSFER_WITH_RECEIPT'): EnhancedPaymentProvider {
    switch (type) {
      case 'BANK_TRANSFER_WITH_RECEIPT':
        return new BankTransferWithReceiptProvider();
      default:
        return new BankTransferWithReceiptProvider();
    }
  }
}

export const paymentProvider = new BankTransferWithReceiptProvider();
