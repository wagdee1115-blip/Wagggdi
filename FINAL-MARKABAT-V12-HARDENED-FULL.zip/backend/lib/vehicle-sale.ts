
// lib/vehicle-sale.ts - نظام البيع ونقل الملكية الكامل - مركبات
// State Machine واضحة + جميع الشروط

import { EscrowService } from './escrow';
import { ExchangeRateProvider } from './exchange-rate';
import { OtpService } from './otp';
import { GovernmentIntegration } from './government';
import { BankTransferWithReceiptProvider } from './payment-provider';

export type SaleStatus =
  | 'PENDING_SELLER'
  | 'BUYER_IDENTIFIED'
  | 'WAITING_BUYER_APPROVAL'
  | 'BUYER_APPROVED'
  | 'BUYER_OTP_VERIFIED'
  | 'WAITING_PAYMENT'
  | 'PAYMENT_PENDING_VERIFICATION'
  | 'PAYMENT_VERIFIED'
  | 'FUNDS_SECURED'
  | 'WAITING_SELLER_CONFIRMATION'
  | 'SELLER_OTP_VERIFIED'
  | 'TRANSFER_IN_PROGRESS'
  | 'OWNERSHIP_TRANSFERRED'
  | 'RELEASE_PENDING'
  | 'RELEASE_READY'
  | 'RELEASE_PROCESSING'
  | 'FUNDS_RELEASED'
  | 'CONTRACT_GENERATED'
  | 'COMPLETED'
  | 'REJECTED'
  | 'CANCELLED'
  | 'PAYMENT_FAILED'
  | 'TRANSFER_FAILED'
  | 'RELEASE_FAILED'
  | 'EXPIRED';

export interface VehicleSaleOperation {
  id: string;
  vehicleId: string;
  vehicleData: {
    plateNumber: string;
    vin: string;
    make: string;
    model: string;
    year: number;
    color: string;
    mileage: number;
    imageUrl?: string;
  };
  sellerId: string;
  sellerName: string;
  sellerNationalId: string;
  sellerPhone: string;
  sellerVerified: boolean;
  
  buyerId?: string;
  buyerName?: string;
  buyerNationalId?: string;
  buyerPhone?: string;
  buyerVerified: boolean;
  buyerApproved: boolean;
  
  vehicleAmountYER: number; // قيمة المركبة بالريال - يحددها البائع
  platformFeeUSD: number; // 80 USD
  platformFeeYER: number; // 80 * exchangeRate
  governmentFeesYER: number; // 0 حاليا
  totalPaidYER: number;
  sellerPayoutYER: number;
  platformRevenueYER: number;
  
  exchangeRate: number; // مثبت وقت العملية
  exchangeRateId: string;
  
  paymentMethod: string;
  paymentReceiptId?: string;
  paymentVerified: boolean;
  fundsSecured: boolean;
  
  buyerOtpId?: string;
  buyerOtpVerified: boolean;
  sellerOtpId?: string;
  sellerOtpVerified: boolean;
  
  escrowTransactionId?: string;
  
  governmentReference?: string;
  governmentStatus?: string;
  
  status: SaleStatus;
  statusHistory: { status: SaleStatus; timestamp: Date; changedBy: string; notes?: string }[];
  
  vehicleEligible: boolean;
  
  contractId?: string;
  electronicDocumentUrl?: string;
  
  releaseReadyAt?: Date; // +15 دقيقة
  
  createdAt: Date;
  updatedAt: Date;
  expiresAt: Date;
}

export interface SaleAuditLogEntry {
  id: string;
  operationId: string;
  userId: string;
  userName: string;
  action: string;
  oldStatus?: SaleStatus;
  newStatus: SaleStatus;
  reference?: string;
  metadata?: any;
  createdAt: Date;
  // لا نحفظ OTP
}

export class VehicleSaleService {
  private operations: Map<string, VehicleSaleOperation> = new Map();
  private auditLogs: SaleAuditLogEntry[] = [];
  private escrowService: EscrowService;
  private exchangeRateProvider: ExchangeRateProvider;
  private otpService: OtpService;
  private governmentIntegration: GovernmentIntegration;
  private paymentProvider: BankTransferWithReceiptProvider;

  constructor(
    escrowService?: EscrowService,
    exchangeRateProvider?: ExchangeRateProvider,
    otpService?: OtpService,
    governmentIntegration?: GovernmentIntegration,
    paymentProvider?: BankTransferWithReceiptProvider
  ) {
    this.escrowService = escrowService || new EscrowService();
    this.exchangeRateProvider = exchangeRateProvider || new ExchangeRateProvider();
    this.otpService = otpService || new OtpService();
    this.governmentIntegration = governmentIntegration || new GovernmentIntegration();
    this.paymentProvider = paymentProvider || new BankTransferWithReceiptProvider();
  }

  // إنشاء عملية بيع - البائع يختار مركبة ويدخل بيانات المشتري
  async createSaleOperation(params: {
    vehicleId: string;
    vehicleData: VehicleSaleOperation['vehicleData'];
    sellerId: string;
    sellerName: string;
    sellerNationalId: string;
    sellerPhone: string;
    sellerVerified: boolean;
    buyerPhoneInput: string;
    vehicleAmountYER: number; // بالريال اليمني
    createdBy: string;
    createdByName: string;
  }): Promise<VehicleSaleOperation> {
    // منع: بيع مركبة ليست باسمه - يتحقق في API layer
    if (!params.sellerVerified) {
      throw new Error('Seller not verified - Cannot create sale operation');
    }

    if (params.vehicleAmountYER <= 0) {
      throw new Error('Vehicle amount must be positive and in YER');
    }

    const exchangeRate = this.exchangeRateProvider.getCurrentRate();
    const platformFeeUSD = 80;
    const platformFeeYER = platformFeeUSD * exchangeRate.usdToYer;
    const governmentFeesYER = 0;
    const totalPaidYER = params.vehicleAmountYER + platformFeeYER + governmentFeesYER;

    const operation: VehicleSaleOperation = {
      id: `SALE-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      vehicleId: params.vehicleId,
      vehicleData: params.vehicleData,
      sellerId: params.sellerId,
      sellerName: params.sellerName,
      sellerNationalId: params.sellerNationalId,
      sellerPhone: params.sellerPhone,
      sellerVerified: params.sellerVerified,
      buyerVerified: false,
      buyerApproved: false,
      vehicleAmountYER: params.vehicleAmountYER,
      platformFeeUSD,
      platformFeeYER,
      governmentFeesYER,
      totalPaidYER,
      sellerPayoutYER: params.vehicleAmountYER,
      platformRevenueYER: platformFeeYER,
      exchangeRate: exchangeRate.usdToYer,
      exchangeRateId: exchangeRate.id,
      paymentMethod: 'BANK_TRANSFER',
      paymentVerified: false,
      fundsSecured: false,
      buyerOtpVerified: false,
      sellerOtpVerified: false,
      status: 'PENDING_SELLER',
      statusHistory: [{ status: 'PENDING_SELLER', timestamp: new Date(), changedBy: params.createdBy }],
      vehicleEligible: true, // يفحص لاحقا
      createdAt: new Date(),
      updatedAt: new Date(),
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 أيام
    };

    this.operations.set(operation.id, operation);

    await this.addAuditLog({
      operationId: operation.id,
      userId: params.createdBy,
      userName: params.createdByName,
      action: 'CREATE_SALE_OPERATION',
      newStatus: 'PENDING_SELLER',
      reference: params.vehicleId,
      metadata: { vehicleAmountYER: params.vehicleAmountYER, buyerPhoneInput: params.buyerPhoneInput },
    });

    return operation;
  }

  // تحديد المشتري والتحقق منه
  async identifyBuyer(params: {
    operationId: string;
    buyerId: string;
    buyerName: string;
    buyerNationalId: string;
    buyerPhone: string;
    buyerVerified: boolean;
    identifiedBy: string;
    identifiedByName: string;
  }): Promise<VehicleSaleOperation> {
    const op = this.operations.get(params.operationId);
    if (!op) throw new Error('Operation not found');

    if (op.status !== 'PENDING_SELLER') {
      throw new Error('Invalid status for buyer identification');
    }

    op.buyerId = params.buyerId;
    op.buyerName = params.buyerName;
    op.buyerNationalId = params.buyerNationalId;
    op.buyerPhone = params.buyerPhone;
    op.buyerVerified = params.buyerVerified;
    op.status = 'BUYER_IDENTIFIED';
    op.updatedAt = new Date();
    op.statusHistory.push({ status: 'BUYER_IDENTIFIED', timestamp: new Date(), changedBy: params.identifiedBy });

    this.operations.set(op.id, op);

    await this.addAuditLog({
      operationId: op.id,
      userId: params.identifiedBy,
      userName: params.identifiedByName,
      action: 'BUYER_IDENTIFIED',
      oldStatus: 'PENDING_SELLER',
      newStatus: 'BUYER_IDENTIFIED',
      reference: params.buyerId,
    });

    // إرسال إشعار للمشتري
    // الانتقال لـ WAITING_BUYER_APPROVAL
    op.status = 'WAITING_BUYER_APPROVAL';
    op.statusHistory.push({ status: 'WAITING_BUYER_APPROVAL', timestamp: new Date(), changedBy: params.identifiedBy });
    op.updatedAt = new Date();
    this.operations.set(op.id, op);

    await this.addAuditLog({
      operationId: op.id,
      userId: params.identifiedBy,
      userName: params.identifiedByName,
      action: 'WAITING_BUYER_APPROVAL',
      oldStatus: 'BUYER_IDENTIFIED',
      newStatus: 'WAITING_BUYER_APPROVAL',
    });

    return op;
  }

  // موافقة المشتري
  async buyerApprove(operationId: string, buyerId: string, buyerName: string): Promise<VehicleSaleOperation> {
    const op = this.operations.get(operationId);
    if (!op) throw new Error('Operation not found');
    if (op.buyerId !== buyerId) throw new Error('Buyer mismatch');
    if (op.status !== 'WAITING_BUYER_APPROVAL') throw new Error('Invalid status');

    op.buyerApproved = true;
    op.status = 'BUYER_APPROVED';
    op.updatedAt = new Date();
    op.statusHistory.push({ status: 'BUYER_APPROVED', timestamp: new Date(), changedBy: buyerId });

    this.operations.set(op.id, op);

    await this.addAuditLog({
      operationId: op.id,
      userId: buyerId,
      userName: buyerName,
      action: 'BUYER_APPROVED',
      oldStatus: 'WAITING_BUYER_APPROVAL',
      newStatus: 'BUYER_APPROVED',
    });

    return op;
  }

  // رفض المشتري
  async buyerReject(operationId: string, buyerId: string, buyerName: string, reason?: string): Promise<VehicleSaleOperation> {
    const op = this.operations.get(operationId);
    if (!op) throw new Error('Operation not found');
    if (op.buyerId !== buyerId) throw new Error('Buyer mismatch');

    op.status = 'REJECTED';
    op.updatedAt = new Date();
    op.statusHistory.push({ status: 'REJECTED', timestamp: new Date(), changedBy: buyerId, notes: reason });

    this.operations.set(op.id, op);

    await this.addAuditLog({
      operationId: op.id,
      userId: buyerId,
      userName: buyerName,
      action: 'BUYER_REJECTED',
      oldStatus: op.statusHistory[op.statusHistory.length - 2]?.status,
      newStatus: 'REJECTED',
      metadata: { reason },
    });

    return op;
  }

  // إرسال OTP للمشتري
  async sendBuyerOtp(operationId: string, requestedBy: string, requestedByName: string): Promise<{ otpId: string; expiresAt: Date; testOtp?: string }> {
    const op = this.operations.get(operationId);
    if (!op) throw new Error('Operation not found');
    if (!op.buyerId || !op.buyerPhone) throw new Error('Buyer not identified');
    if (op.status !== 'BUYER_APPROVED') throw new Error('Buyer not approved yet');

    const result = await this.otpService.sendOtp({
      phone: op.buyerPhone,
      operationId: op.id,
      type: 'BUYER',
    });

    op.buyerOtpId = result.otpId;
    op.updatedAt = new Date();
    this.operations.set(op.id, op);

    await this.addAuditLog({
      operationId: op.id,
      userId: requestedBy,
      userName: requestedByName,
      action: 'BUYER_OTP_SENT',
      newStatus: op.status,
      reference: result.otpId,
    });

    return result;
  }

  // التحقق من OTP المشتري
  async verifyBuyerOtp(params: { operationId: string; otpId: string; otp: string; verifiedBy: string; verifiedByName: string }): Promise<VehicleSaleOperation> {
    const op = this.operations.get(params.operationId);
    if (!op) throw new Error('Operation not found');

    const verification = await this.otpService.verifyOtp({
      otpId: params.otpId,
      otp: params.otp,
      operationId: op.id,
      type: 'BUYER',
    });

    if (!verification.verified) throw new Error('Buyer OTP verification failed');

    op.buyerOtpVerified = true;
    op.status = 'BUYER_OTP_VERIFIED';
    op.updatedAt = new Date();
    op.statusHistory.push({ status: 'BUYER_OTP_VERIFIED', timestamp: new Date(), changedBy: params.verifiedBy });

    // الانتقال لانتظار الدفع
    op.status = 'WAITING_PAYMENT';
    op.statusHistory.push({ status: 'WAITING_PAYMENT', timestamp: new Date(), changedBy: params.verifiedBy });
    this.operations.set(op.id, op);

    await this.addAuditLog({
      operationId: op.id,
      userId: params.verifiedBy,
      userName: params.verifiedByName,
      action: 'BUYER_OTP_VERIFIED',
      oldStatus: 'BUYER_APPROVED',
      newStatus: 'WAITING_PAYMENT',
    });

    return op;
  }

  // رفع إيصال الدفع - لا يعتبر دليلا على وصول المال
  async uploadPaymentReceipt(params: {
    operationId: string;
    receiptUrl: string;
    receiptFileName: string;
    uploadedBy: string;
    uploadedByName: string;
    method: string;
  }): Promise<VehicleSaleOperation> {
    const op = this.operations.get(params.operationId);
    if (!op) throw new Error('Operation not found');
    if (op.status !== 'WAITING_PAYMENT') throw new Error('Not waiting for payment');

    const receipt = await this.paymentProvider.uploadReceipt({
      operationId: op.id,
      amountYER: op.totalPaidYER,
      receiptUrl: params.receiptUrl,
      receiptFileName: params.receiptFileName,
      uploadedBy: params.uploadedBy,
      method: params.method as any,
    });

    op.paymentReceiptId = receipt.id;
    op.status = 'PAYMENT_PENDING_VERIFICATION';
    op.updatedAt = new Date();
    op.statusHistory.push({ status: 'PAYMENT_PENDING_VERIFICATION', timestamp: new Date(), changedBy: params.uploadedBy });
    this.operations.set(op.id, op);

    await this.addAuditLog({
      operationId: op.id,
      userId: params.uploadedBy,
      userName: params.uploadedByName,
      action: 'PAYMENT_RECEIPT_UPLOADED',
      oldStatus: 'WAITING_PAYMENT',
      newStatus: 'PAYMENT_PENDING_VERIFICATION',
      reference: receipt.id,
      metadata: { receiptUrl: params.receiptUrl, note: 'Upload alone not proof of payment - Admin verification required' },
    });

    return op;
  }

  // تأكيد وصول المبلغ بواسطة Admin/SUPER_ADMIN
  async verifyPaymentByAdmin(params: {
    operationId: string;
    adminId: string;
    adminName: string;
    adminRole: string;
    bankReference?: string;
  }): Promise<VehicleSaleOperation> {
    const op = this.operations.get(params.operationId);
    if (!op) throw new Error('Operation not found');

    if (params.adminRole !== 'ADMIN' && params.adminRole !== 'SUPER_ADMIN' && params.adminRole !== 'OWNER' && params.adminRole !== 'FINANCE') {
      throw new Error('Only Admin/Super Admin/Finance can verify payment');
    }

    if (op.status !== 'PAYMENT_PENDING_VERIFICATION') throw new Error('No receipt pending verification');

    if (!op.paymentReceiptId) throw new Error('No receipt');

    await this.paymentProvider.verifyPaymentByAdmin(op.paymentReceiptId, params.adminId, params.adminName, params.bankReference);

    // إنشاء escrow transaction
    const escrowTx = await this.escrowService.createEscrowTransaction({
      vehicleSaleId: op.id,
      vehicleAmountYER: op.vehicleAmountYER,
      platformFeeUSD: op.platformFeeUSD,
      exchangeRate: op.exchangeRate,
      governmentFeesYER: op.governmentFeesYER,
    });

    op.escrowTransactionId = escrowTx.id;
    op.paymentVerified = true;
    op.status = 'PAYMENT_VERIFIED';
    op.updatedAt = new Date();
    op.statusHistory.push({ status: 'PAYMENT_VERIFIED', timestamp: new Date(), changedBy: params.adminId });

    // تأمين الأموال
    await this.escrowService.secureFunds(escrowTx.id);
    op.fundsSecured = true;
    op.status = 'FUNDS_SECURED';
    op.statusHistory.push({ status: 'FUNDS_SECURED', timestamp: new Date(), changedBy: params.adminId });
    op.updatedAt = new Date();

    this.operations.set(op.id, op);

    await this.addAuditLog({
      operationId: op.id,
      userId: params.adminId,
      userName: params.adminName,
      action: 'PAYMENT_VERIFIED_AND_FUNDS_SECURED',
      oldStatus: 'PAYMENT_PENDING_VERIFICATION',
      newStatus: 'FUNDS_SECURED',
      reference: escrowTx.id,
      metadata: { bankReference: params.bankReference },
    });

    // إشعار البائع: تم تأمين قيمة المركبة
    op.status = 'WAITING_SELLER_CONFIRMATION';
    op.statusHistory.push({ status: 'WAITING_SELLER_CONFIRMATION', timestamp: new Date(), changedBy: params.adminId });
    op.updatedAt = new Date();
    this.operations.set(op.id, op);

    return op;
  }

  // إرسال OTP للبائع
  async sendSellerOtp(operationId: string, requestedBy: string, requestedByName: string): Promise<{ otpId: string; expiresAt: Date; testOtp?: string }> {
    const op = this.operations.get(operationId);
    if (!op) throw new Error('Operation not found');
    if (op.status !== 'WAITING_SELLER_CONFIRMATION') throw new Error('Not waiting for seller confirmation');
    if (!op.fundsSecured) throw new Error('Funds not secured');

    const result = await this.otpService.sendOtp({
      phone: op.sellerPhone,
      operationId: op.id,
      type: 'SELLER',
    });

    op.sellerOtpId = result.otpId;
    op.updatedAt = new Date();
    this.operations.set(op.id, op);

    await this.addAuditLog({
      operationId: op.id,
      userId: requestedBy,
      userName: requestedByName,
      action: 'SELLER_OTP_SENT',
      newStatus: op.status,
      reference: result.otpId,
    });

    return result;
  }

  // التحقق من OTP البائع
  async verifySellerOtp(params: { operationId: string; otpId: string; otp: string; verifiedBy: string; verifiedByName: string }): Promise<VehicleSaleOperation> {
    const op = this.operations.get(params.operationId);
    if (!op) throw new Error('Operation not found');

    const verification = await this.otpService.verifyOtp({
      otpId: params.otpId,
      otp: params.otp,
      operationId: op.id,
      type: 'SELLER',
    });

    if (!verification.verified) throw new Error('Seller OTP verification failed');

    op.sellerOtpVerified = true;
    op.status = 'SELLER_OTP_VERIFIED';
    op.updatedAt = new Date();
    op.statusHistory.push({ status: 'SELLER_OTP_VERIFIED', timestamp: new Date(), changedBy: params.verifiedBy });

    this.operations.set(op.id, op);

    await this.addAuditLog({
      operationId: op.id,
      userId: params.verifiedBy,
      userName: params.verifiedByName,
      action: 'SELLER_OTP_VERIFIED',
      oldStatus: 'WAITING_SELLER_CONFIRMATION',
      newStatus: 'SELLER_OTP_VERIFIED',
    });

    // إرسال للمرور فورا - الهدف أقل من 30 دقيقة
    return await this.submitToGovernment(op.id, params.verifiedBy, params.verifiedByName);
  }

  // إرسال للمرور
  async submitToGovernment(operationId: string, submittedBy: string, submittedByName: string): Promise<VehicleSaleOperation> {
    const op = this.operations.get(operationId);
    if (!op) throw new Error('Operation not found');

    if (!op.sellerOtpVerified || !op.buyerOtpVerified || !op.paymentVerified || !op.fundsSecured) {
      throw new Error('Not eligible for government transfer - Missing conditions');
    }

    op.status = 'TRANSFER_IN_PROGRESS';
    op.updatedAt = new Date();
    op.statusHistory.push({ status: 'TRANSFER_IN_PROGRESS', timestamp: new Date(), changedBy: submittedBy });

    try {
      const govResponse = await this.governmentIntegration.submitTransferIfEligible({
        operationId: op.id,
        vehicleId: op.vehicleId,
        plateNumber: op.vehicleData.plateNumber,
        vin: op.vehicleData.vin,
        sellerId: op.sellerId,
        sellerNationalId: op.sellerNationalId,
        sellerVerified: op.sellerVerified,
        buyerId: op.buyerId!,
        buyerNationalId: op.buyerNationalId!,
        buyerVerified: op.buyerVerified,
        buyerApproved: op.buyerApproved,
        buyerOtpVerified: op.buyerOtpVerified,
        paymentVerified: op.paymentVerified,
        fundsSecured: op.fundsSecured,
        sellerOtpVerified: op.sellerOtpVerified,
        vehicleEligible: op.vehicleEligible,
        salePrice: op.vehicleAmountYER,
      });

      op.governmentReference = govResponse.governmentReference;
      op.governmentStatus = govResponse.status;
      op.updatedAt = new Date();
      this.operations.set(op.id, op);

      await this.addAuditLog({
        operationId: op.id,
        userId: submittedBy,
        userName: submittedByName,
        action: 'GOVERNMENT_TRANSFER_SUBMITTED',
        oldStatus: 'SELLER_OTP_VERIFIED',
        newStatus: 'TRANSFER_IN_PROGRESS',
        reference: govResponse.governmentReference,
      });

    } catch (error: any) {
      op.status = 'TRANSFER_FAILED';
      op.updatedAt = new Date();
      op.statusHistory.push({ status: 'TRANSFER_FAILED', timestamp: new Date(), changedBy: submittedBy, notes: error.message });
      this.operations.set(op.id, op);

      await this.addAuditLog({
        operationId: op.id,
        userId: submittedBy,
        userName: submittedByName,
        action: 'GOVERNMENT_TRANSFER_FAILED',
        oldStatus: 'SELLER_OTP_VERIFIED',
        newStatus: 'TRANSFER_FAILED',
        metadata: { error: error.message },
      });

      throw error;
    }

    return op;
  }

  // تأكيد نجاح نقل الملكية - فقط OWNER/SUPER_ADMIN في TEST/DEMO
  async confirmOwnershipTransferred(params: {
    operationId: string;
    governmentReference: string;
    confirmedBy: string;
    confirmedByName: string;
    role: string;
  }): Promise<VehicleSaleOperation> {
    const op = this.operations.get(params.operationId);
    if (!op) throw new Error('Operation not found');

    if (op.status !== 'TRANSFER_IN_PROGRESS') throw new Error('Not in progress');

    // في TEST/DEMO فقط OWNER/SUPER_ADMIN
    if (params.role !== 'OWNER' && params.role !== 'SUPER_ADMIN') {
      throw new Error('Only OWNER/SUPER_ADMIN can confirm ownership transferred in TEST/DEMO');
    }

    // محاكاة موافقة المرور
    await this.governmentIntegration.mockApprove(params.governmentReference, params.confirmedBy, params.role);

    op.status = 'OWNERSHIP_TRANSFERRED';
    op.updatedAt = new Date();
    op.statusHistory.push({ status: 'OWNERSHIP_TRANSFERRED', timestamp: new Date(), changedBy: params.confirmedBy });

    // الحصول على الاستمارة من المرور - لا ننشئها بأنفسنا
    try {
      const doc = await this.governmentIntegration.getElectronicDocument(params.governmentReference);
      op.electronicDocumentUrl = doc.url || `/documents/${params.governmentReference}`;
    } catch {}

    // بدء فترة الحماية 15 دقيقة
    if (op.escrowTransactionId) {
      await this.escrowService.startReleaseProtection(op.escrowTransactionId);
      op.releaseReadyAt = new Date(Date.now() + 15 * 60 * 1000);
    }

    op.status = 'RELEASE_PENDING';
    op.statusHistory.push({ status: 'RELEASE_PENDING', timestamp: new Date(), changedBy: params.confirmedBy });
    op.updatedAt = new Date();
    this.operations.set(op.id, op);

    await this.addAuditLog({
      operationId: op.id,
      userId: params.confirmedBy,
      userName: params.confirmedByName,
      action: 'OWNERSHIP_TRANSFERRED_AND_RELEASE_PENDING',
      oldStatus: 'TRANSFER_IN_PROGRESS',
      newStatus: 'RELEASE_PENDING',
      reference: params.governmentReference,
    });

    // بعد 15 دقيقة يصبح RELEASE_READY
    // في الإنتاج يتم عبر cron/job

    return op;
  }

  // تحرير الأموال للبائع بعد 15 دقيقة
  async releaseFundsToSeller(operationId: string, releasedBy: string, releasedByName: string): Promise<VehicleSaleOperation> {
    const op = this.operations.get(operationId);
    if (!op) throw new Error('Operation not found');

    if (op.status !== 'RELEASE_PENDING' && op.status !== 'RELEASE_READY') {
      throw new Error('Not ready for release');
    }

    if (op.releaseReadyAt && new Date() < op.releaseReadyAt) {
      // لا يزال في فترة الحماية
      throw new Error('Release protection period not ended - 15 minutes required');
    }

    op.status = 'RELEASE_READY';
    op.statusHistory.push({ status: 'RELEASE_READY', timestamp: new Date(), changedBy: releasedBy });
    op.status = 'RELEASE_PROCESSING';
    op.statusHistory.push({ status: 'RELEASE_PROCESSING', timestamp: new Date(), changedBy: releasedBy });
    op.updatedAt = new Date();
    this.operations.set(op.id, op);

    try {
      if (op.escrowTransactionId) {
        await this.escrowService.releaseToSeller(op.escrowTransactionId);
      }

      op.status = 'FUNDS_RELEASED';
      op.statusHistory.push({ status: 'FUNDS_RELEASED', timestamp: new Date(), changedBy: releasedBy });
      op.updatedAt = new Date();
      this.operations.set(op.id, op);

      await this.addAuditLog({
        operationId: op.id,
        userId: releasedBy,
        userName: releasedByName,
        action: 'FUNDS_RELEASED_TO_SELLER',
        oldStatus: 'RELEASE_PROCESSING',
        newStatus: 'FUNDS_RELEASED',
        metadata: { sellerPayout: op.sellerPayoutYER },
      });

      // إنشاء العقد
      op.status = 'CONTRACT_GENERATED';
      op.statusHistory.push({ status: 'CONTRACT_GENERATED', timestamp: new Date(), changedBy: releasedBy });
      op.contractId = `CONTRACT-${op.id}`;
      op.updatedAt = new Date();
      this.operations.set(op.id, op);

      op.status = 'COMPLETED';
      op.statusHistory.push({ status: 'COMPLETED', timestamp: new Date(), changedBy: releasedBy });
      op.updatedAt = new Date();
      this.operations.set(op.id, op);

      await this.addAuditLog({
        operationId: op.id,
        userId: releasedBy,
        userName: releasedByName,
        action: 'SALE_COMPLETED',
        oldStatus: 'CONTRACT_GENERATED',
        newStatus: 'COMPLETED',
      });

    } catch (error: any) {
      op.status = 'RELEASE_FAILED';
      op.statusHistory.push({ status: 'RELEASE_FAILED', timestamp: new Date(), changedBy: releasedBy, notes: error.message });
      op.updatedAt = new Date();
      this.operations.set(op.id, op);

      if (op.escrowTransactionId) {
        await this.escrowService.markReleaseFailed(op.escrowTransactionId, error.message);
      }

      await this.addAuditLog({
        operationId: op.id,
        userId: releasedBy,
        userName: releasedByName,
        action: 'FUNDS_RELEASE_FAILED',
        oldStatus: 'RELEASE_PROCESSING',
        newStatus: 'RELEASE_FAILED',
        metadata: { error: error.message, note: 'Funds remain protected' },
      });

      throw error;
    }

    return op;
  }

  private async addAuditLog(entry: Omit<SaleAuditLogEntry, 'id' | 'createdAt'>): Promise<void> {
    const log: SaleAuditLogEntry = {
      id: `AUDIT-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      ...entry,
      createdAt: new Date(),
    };
    this.auditLogs.push(log);
  }

  getOperation(id: string): VehicleSaleOperation | undefined {
    return this.operations.get(id);
  }

  getOperationsBySeller(sellerId: string): VehicleSaleOperation[] {
    return Array.from(this.operations.values()).filter(o => o.sellerId === sellerId);
  }

  getOperationsByBuyer(buyerId: string): VehicleSaleOperation[] {
    return Array.from(this.operations.values()).filter(o => o.buyerId === buyerId);
  }

  getAuditLogs(operationId: string): SaleAuditLogEntry[] {
    return this.auditLogs.filter(l => l.operationId === operationId).sort((a,b) => a.createdAt.getTime() - b.createdAt.getTime());
  }
}

export const vehicleSaleService = new VehicleSaleService();
