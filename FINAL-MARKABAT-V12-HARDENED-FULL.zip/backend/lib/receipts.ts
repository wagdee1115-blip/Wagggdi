
// lib/receipts.ts - نظام الإيصالات - مركبات V11

export interface Receipt {
  id: string;
  transactionId: string;
  operationId: string;
  amountYER: number;
  currency: string;
  exchangeRate: number;
  platformFeeYER: number;
  platformFeeUSD: number;
  paymentMethod: string;
  status: string;
  qrCode: string;
  verificationUrl: string;
  hash: string;
  createdAt: Date;
  createdBy: string;
}

export class ReceiptService {
  private receipts: Map<string, Receipt> = new Map();

  async generateReceipt(params: {
    transactionId: string;
    operationId: string;
    amountYER: number;
    platformFeeYER: number;
    platformFeeUSD: number;
    exchangeRate: number;
    paymentMethod: string;
    status: string;
    createdBy: string;
  }): Promise<Receipt> {
    const receiptId = `RECEIPT-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;
    
    // إنشاء Hash للإيصال
    const crypto = await import('crypto');
    const hashData = `${receiptId}-${params.transactionId}-${params.amountYER}-${Date.now()}`;
    const hash = crypto.createHash('sha256').update(hashData).digest('hex');

    const receipt: Receipt = {
      id: receiptId,
      transactionId: params.transactionId,
      operationId: params.operationId,
      amountYER: params.amountYER,
      currency: 'YER',
      exchangeRate: params.exchangeRate,
      platformFeeYER: params.platformFeeYER,
      platformFeeUSD: params.platformFeeUSD,
      paymentMethod: params.paymentMethod,
      status: params.status,
      qrCode: `https://markabat.ye/verify/receipt/${receiptId}`,
      verificationUrl: `https://markabat.ye/verify/receipt/${receiptId}`,
      hash,
      createdAt: new Date(),
      createdBy: params.createdBy,
    };

    this.receipts.set(receiptId, receipt);

    console.log(`[RECEIPT] Generated receipt ${receiptId} for operation ${params.operationId} - ${params.amountYER} YER`);

    return receipt;
  }

  getReceipt(id: string): Receipt | undefined {
    return this.receipts.get(id);
  }

  getReceiptsByOperation(operationId: string): Receipt[] {
    return Array.from(this.receipts.values()).filter(r => r.operationId === operationId);
  }

  verifyReceipt(id: string, hash: string): { valid: boolean; receipt?: Receipt } {
    const receipt = this.receipts.get(id);
    if (!receipt) return { valid: false };

    if (receipt.hash !== hash) {
      return { valid: false };
    }

    return { valid: true, receipt };
  }
}

export const receiptService = new ReceiptService();
