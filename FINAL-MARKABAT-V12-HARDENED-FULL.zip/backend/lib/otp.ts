
// lib/otp.ts - نظام OTP الآمن - مركبات
// Modular - Mock في Development/Test - جاهز للربط مع SMS Provider +967

import { createHash, randomInt, randomUUID } from 'crypto';

export type OtpType = 'BUYER' | 'SELLER';
export type OtpChannel = 'SMS' | 'WHATSAPP' | 'MOCK';

export interface OtpRecord {
  id: string;
  operationId: string; // مرتبط بعملية بيع محددة
  type: OtpType; // BUYER منفصل عن SELLER
  phone: string;
  otpHash: string; // لا نخزن كنص مكشوف
  channel: OtpChannel;
  attempts: number;
  maxAttempts: number;
  expiresAt: Date;
  verifiedAt?: Date;
  isUsed: boolean;
  createdAt: Date;
}

export interface OtpProvider {
  name: string;
  sendOtp(phone: string, otp: string, operationId: string): Promise<{ providerReference: string; channel: OtpChannel }>;
  // لا نكشف OTP في Production
}

export class MockOtpProvider implements OtpProvider {
  name = 'MOCK_OTP';
  
  async sendOtp(phone: string, otp: string, operationId: string) {
    // في Development/Test فقط نظهر OTP في log مخصص للإدارة
    if (process.env.NODE_ENV !== 'production') {
      console.log(`[MOCK OTP - ${phone} - Op:${operationId}]: ${otp} - للاختبار فقط - لا يظهر في Production`);
    }
    return { providerReference: `MOCK-OTP-${Date.now()}`, channel: 'MOCK' as OtpChannel };
  }
}

// مستقبلا: Twilio, SMS Provider يدعم +967
export class FutureSmsProvider implements OtpProvider {
  name = 'FUTURE_SMS_YEMEN';
  async sendOtp(phone: string, otp: string, operationId: string) {
    // جاهز للربط مع مزود يمني يدعم +967
    throw new Error('SMS Provider not configured yet - Ready for integration with Yemeni provider supporting +967. Use Mock in Dev/Test.');
  }
}

export class OtpService {
  private provider: OtpProvider;
  private otps: Map<string, OtpRecord> = new Map();
  private readonly OTP_EXPIRY_MINUTES = 5;
  private readonly MAX_ATTEMPTS = 3;

  constructor(provider?: OtpProvider) {
    this.provider = provider || new MockOtpProvider();
  }

  private hashOtp(otp: string): string {
    return createHash('sha256').update(otp).digest('hex');
  }

  private generateOtp(): string {
    // 6 أرقام
    return randomInt(100000, 1000000).toString();
  }

  // إرسال OTP - مرتبط بعملية محددة
  async sendOtp(params: {
    phone: string;
    operationId: string;
    type: OtpType;
  }): Promise<{ otpId: string; expiresAt: Date; providerReference: string; testOtp?: string }> {
    const { phone, operationId, type } = params;

    // منع التخمين المتكرر - تحقق من وجود OTP نشط لنفس العملية والنوع
    const existing = Array.from(this.otps.values()).find(
      o => o.operationId === operationId && o.type === type && !o.isUsed && o.expiresAt > new Date()
    );
    if (existing) {
      // إذا موجود OTP نشط - لا ترسل جديد إلا بعد انتهاء القديم أو 1 دقيقة
      const timeSinceCreation = Date.now() - existing.createdAt.getTime();
      if (timeSinceCreation < 60 * 1000) {
        throw new Error('OTP already sent - Please wait 60 seconds before requesting new OTP');
      }
    }

    const otp = this.generateOtp();
    const otpHash = this.hashOtp(otp);
    const expiresAt = new Date(Date.now() + this.OTP_EXPIRY_MINUTES * 60 * 1000);

    const record: OtpRecord = {
      id: `OTP-${randomUUID()}`, 
      operationId,
      type,
      phone,
      otpHash,
      channel: 'MOCK',
      attempts: 0,
      maxAttempts: this.MAX_ATTEMPTS,
      expiresAt,
      isUsed: false,
      createdAt: new Date(),
    };

    this.otps.set(record.id, record);

    const providerResult = await this.provider.sendOtp(phone, otp, operationId);

    // في Development/Test فقط نرجع OTP للاختبار - في Production لا نرجعه
    const isDev = process.env.NODE_ENV !== 'production';
    
    return {
      otpId: record.id,
      expiresAt,
      providerReference: providerResult.providerReference,
      ...(isDev ? { testOtp: otp } : {}), // فقط في Dev/Test
    };
  }

  // التحقق من OTP
  async verifyOtp(params: {
    otpId: string;
    otp: string;
    operationId: string;
    type: OtpType;
  }): Promise<{ verified: boolean; record: OtpRecord }> {
    const { otpId, otp, operationId, type } = params;

    const record = this.otps.get(otpId);
    if (!record) {
      throw new Error('OTP not found');
    }

    if (record.operationId !== operationId || record.type !== type) {
      throw new Error('OTP does not match operation');
    }

    if (record.isUsed) {
      throw new Error('OTP already used - Cannot reuse');
    }

    if (new Date() > record.expiresAt) {
      throw new Error('OTP expired');
    }

    if (record.attempts >= record.maxAttempts) {
      throw new Error('Max attempts exceeded - OTP blocked');
    }

    // زيادة المحاولات
    record.attempts += 1;
    this.otps.set(otpId, record);

    const hashedInput = this.hashOtp(otp);
    
    const isValid = hashedInput === record.otpHash;

    if (!isValid) {
      if (record.attempts >= record.maxAttempts) {
        throw new Error('Invalid OTP - Max attempts exceeded');
      }
      throw new Error(`Invalid OTP - Attempts left: ${record.maxAttempts - record.attempts}`);
    }

    // صحيح - لا يمكن إعادة استخدامه
    record.isUsed = true;
    record.verifiedAt = new Date();
    this.otps.set(otpId, record);

    return { verified: true, record };
  }

  // تنظيف OTP منتهي
  cleanupExpired(): number {
    const now = new Date();
    let count = 0;
    for (const [id, record] of this.otps.entries()) {
      if (now > record.expiresAt || record.isUsed) {
        // احتفظ بالسجلات المستخدمة لـ Audit لكن احذف المنتهية غير المستخدمة
        if (!record.isUsed && now > record.expiresAt) {
          this.otps.delete(id);
          count++;
        }
      }
    }
    return count;
  }

  // للاختبار فقط - الحصول على OTP نشط (Development فقط)
  getTestOtp(operationId: string, type: OtpType): string | null {
    if (process.env.NODE_ENV === 'production') {
      throw new Error('Test OTP not available in production');
    }
    const active = Array.from(this.otps.values()).find(o => o.operationId === operationId && o.type === type && !o.isUsed && o.expiresAt > new Date());
    return active ? null : null;
  }

  getRecord(otpId: string): OtpRecord | undefined {
    return this.otps.get(otpId);
  }
}

export const otpService = new OtpService();
