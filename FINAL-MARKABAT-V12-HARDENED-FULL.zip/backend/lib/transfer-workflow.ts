import { Prisma } from '@prisma/client';
import { db } from './db';

export const PLATFORM_FEE_USD = 80;

export async function createOwnershipTransfer(params: {
  vehicleId: string; sellerId: string; buyerId: string; salePrice: number;
}) {
  if (params.sellerId === params.buyerId) throw new Error('SELLER_AND_BUYER_MUST_DIFFER');
  if (!Number.isFinite(params.salePrice) || params.salePrice <= 0) throw new Error('INVALID_PRICE');

  return db.$transaction(async tx => {
    const vehicle = await tx.vehicle.findUnique({ where: { id: params.vehicleId }, include: { owner: true } });
    if (!vehicle) throw new Error('VEHICLE_NOT_FOUND');
    if (vehicle.ownerId !== params.sellerId) throw new Error('NOT_VEHICLE_OWNER');
    if (vehicle.owner.identityStatus !== 'VERIFIED' || vehicle.owner.phoneStatus !== 'VERIFIED') throw new Error('SELLER_NOT_VERIFIED');
    if (vehicle.status !== 'ACTIVE') throw new Error('VEHICLE_NOT_AVAILABLE');
    if (vehicle.governmentStatus === 'BLOCKED' || vehicle.governmentStatus === 'RESTRICTED') throw new Error('VEHICLE_RESTRICTED');

    // Atomic availability lock: only one transaction can move ACTIVE -> PENDING.
    const locked = await tx.vehicle.updateMany({
      where: { id: params.vehicleId, ownerId: params.sellerId, status: 'ACTIVE' },
      data: { status: 'PENDING' },
    });
    if (locked.count !== 1) throw new Error('VEHICLE_ALREADY_LOCKED');

    const buyer = await tx.user.findUnique({ where: { id: params.buyerId } });
    if (!buyer || buyer.status !== 'ACTIVE') throw new Error('BUYER_NOT_ACTIVE');
    if (buyer.identityStatus !== 'VERIFIED' || buyer.phoneStatus !== 'VERIFIED') throw new Error('BUYER_NOT_VERIFIED');

    const exchange = await tx.exchangeRate.findFirst({ orderBy: { updatedAt: 'desc' } });
    if (!exchange) throw new Error('EXCHANGE_RATE_NOT_CONFIGURED');
    const feeYER = new Prisma.Decimal(PLATFORM_FEE_USD).mul(exchange.usdToYer);
    const price = new Prisma.Decimal(params.salePrice);

    const sale = await tx.vehicleSale.create({
      data: {
        vehicleId: params.vehicleId, sellerId: params.sellerId, sellerName: vehicle.owner.fullName,
        sellerNationalId: vehicle.owner.nationalId, sellerPhone: vehicle.owner.phone, sellerVerified: vehicle.owner.identityStatus === 'VERIFIED',
        buyerId: params.buyerId, buyerName: buyer.fullName, buyerNationalId: buyer.nationalId, buyerPhone: buyer.phone,
        vehicleAmountYER: price, platformFeeUSD: PLATFORM_FEE_USD, platformFeeYER: feeYER,
        governmentFeesYER: 0, totalPaidYER: price.add(feeYER), sellerPayoutYER: price, platformRevenueYER: feeYER,
        exchangeRate: exchange.usdToYer, exchangeRateId: exchange.id, status: 'BUYER_IDENTIFIED',
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
      },
    });

    await tx.saleAuditLog.create({ data: { vehicleSaleId: sale.id, userId: params.sellerId, userName: vehicle.owner.fullName, action: 'CREATE_TRANSFER', newStatus: 'BUYER_IDENTIFIED' } });
    return sale;
  });
}

export async function advanceSaleStatus(saleId: string, nextStatus: any, actorId: string, metadata?: Prisma.InputJsonValue) {
  return db.$transaction(async tx => {
    const sale = await tx.vehicleSale.findUnique({ where: { id: saleId } });
    if (!sale) throw new Error('SALE_NOT_FOUND');
    const actor = await tx.user.findUnique({ where: { id: actorId } });
    if (!actor) throw new Error('ACTOR_NOT_FOUND');
    const history = Array.isArray(sale.statusHistory) ? sale.statusHistory : [];
    const updated = await tx.vehicleSale.update({ where: { id: saleId }, data: { status: nextStatus, statusHistory: [...history, { event: nextStatus, at: new Date().toISOString(), actorId, ...(metadata ? { metadata } : {}) }] } });
    await tx.saleAuditLog.create({ data: { vehicleSaleId: saleId, userId: actorId, userName: actor.fullName, action: 'STATUS_CHANGE', oldStatus: sale.status, newStatus: nextStatus, metadata } });
    return updated;
  });
}
