
<!-- Vehicle Sale Flow - Modular Addition - مركبات V11 -->
<script>
// Vehicle Sale System - Modular - Added on top of existing V8 without breaking
(function() {
  const mockUsers = {
    '777111222': { name: 'وجدي - البائع', id: '1234567890', city: 'إب', verified: true, phone: '777111222' },
    '777333444': { name: 'أحمد محمد - المشتري', id: '0987654321', city: 'صنعاء', verified: true, phone: '777333444' },
    '777555666': { name: 'سالم علي', id: '1122334455', city: 'عدن', verified: true, phone: '777555666' }
  };

  const mockVehicles = [
    { id: 'v1', ownerPhone: '777111222', brand: 'TOYOTA', model: 'كامري 2022 فل كامل', plate: 'أ ب ج 1234', chassis: 'JTDKARFU8H1234567', mileage: 45000, color: 'أبيض', year: 2022, image: 'https://images.unsplash.com/photo-1550355291-bbee04a92027?w=600', price: 10000000 },
    { id: 'v2', ownerPhone: '777111222', brand: 'LEXUS', model: 'LX600 2023', plate: 'س د ع 5678', chassis: 'JTJAB7CX0P4012345', mileage: 12000, color: 'أسود', year: 2023, image: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?w=600', price: 25000000 },
    { id: 'v3', ownerPhone: '777111222', brand: 'MERCEDES', model: 'S500 2021', plate: 'هـ و ز 9012', chassis: 'WDDUG8CB0MA123456', mileage: 32000, color: 'فضي', year: 2021, image: 'https://images.unsplash.com/photo-1555215695-3004980ad54e?w=600', price: 18000000 }
  ];

  let currentUser = null;
  let currentSale = null;
  let notifications = [];

  // Load from localStorage
  try {
    currentUser = JSON.parse(localStorage.getItem('markabat_current_user') || 'null');
    currentSale = JSON.parse(localStorage.getItem('markabat_current_sale') || 'null');
    notifications = JSON.parse(localStorage.getItem('markabat_notifications') || '[]');
  } catch(e) {}

  // Override toast buttons to real navigation
  window.addEventListener('load', function() {
    setTimeout(() => {
      // Find and override "بيع سيارتك" buttons
      document.querySelectorAll('button').forEach(btn => {
        const text = btn.textContent.trim();
        if (text.includes('بيع سيارتك') || text.includes('ابدأ بيع')) {
          btn.onclick = function(e) {
            e.preventDefault();
            if (!currentUser) {
              openLoginModal();
              return;
            }
            openSellFlow();
          };
        }
        if (text.includes('تسجيل دخول')) {
          btn.onclick = function(e) {
            e.preventDefault();
            openLoginModal();
          };
        }
        if (text.includes('نقل ملكية') && !text.includes('بيع')) {
          btn.onclick = function(e) {
            e.preventDefault();
            if (!currentUser) {
              openLoginModal();
              return;
            }
            openSellFlow();
          };
        }
      });

      // Add notification bell if not exists
      addNotificationBell();
      
      // Add App Shell enhancements
      enhanceAppShell();
    }, 1500);
  });

  function addNotificationBell() {
    const header = document.querySelector('header');
    if (!header || document.getElementById('markabat-notif-bell')) return;

    const bell = document.createElement('div');
    bell.id = 'markabat-notif-bell';
    bell.innerHTML = `
      <div style="position:relative; cursor:pointer; margin-left:12px;" onclick="window.markabatSale.openNotifications()">
        <div style="width:40px; height:40px; border-radius:50%; background:#0f3d2e; display:flex; align-items:center; justify-content:center; color:white; font-size:18px;">🔔</div>
        <div id="notif-count" style="position:absolute; top:-5px; right:-5px; background:#ef4444; color:white; border-radius:50%; width:20px; height:20px; display:flex; align-items:center; justify-content:center; font-size:11px; font-weight:900; display:${notifications.length > 0 ? 'flex' : 'none'}">${notifications.length}</div>
      </div>
    `;
    
    const headerActions = header.querySelector('.flex.items-center.gap-2') || header.querySelector('div.flex');
    if (headerActions) {
      headerActions.prepend(bell);
    }
  }

  function enhanceAppShell() {
    // Add skeleton loader styles
    const style = document.createElement('style');
    style.textContent = `
      .skeleton { background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%); background-size: 200% 100%; animation: shimmer 1.5s infinite; }
      @keyframes shimmer { 0% { background-position: -200% 0; } 100% { background-position: 200% 0; } }
      .page-transition { animation: slideIn 0.3s ease; }
      @keyframes slideIn { from { opacity:0; transform: translateY(10px); } to { opacity:1; transform: translateY(0); } }
      .offline-overlay { position:fixed; inset:0; background:rgba(15,61,46,0.95); z-index:9999; display:none; align-items:center; justify-content:center; color:white; text-align:center; padding:20px; }
      .offline-overlay.show { display:flex; }
    `;
    document.head.appendChild(style);

    // Offline overlay
    const offlineDiv = document.createElement('div');
    offlineDiv.className = 'offline-overlay';
    offlineDiv.id = 'offline-overlay';
    offlineDiv.innerHTML = `
      <div>
        <div style="font-size:64px; margin-bottom:20px;">🚗</div>
        <h2 style="font-size:24px; font-weight:900; margin-bottom:10px;">أنت غير متصل</h2>
        <p style="font-size:14px; opacity:0.8; margin-bottom:20px;">تحقق من الاتصال بالإنترنت - يمكنك تصفح البيانات المحفوظة</p>
        <button onclick="location.reload()" style="background:#D4AF37; color:#0f3d2e; padding:12px 24px; border-radius:999px; font-weight:900; border:none; cursor:pointer;">إعادة المحاولة</button>
      </div>
    `;
    document.body.appendChild(offlineDiv);

    window.addEventListener('online', () => {
      document.getElementById('offline-overlay').classList.remove('show');
    });
    window.addEventListener('offline', () => {
      document.getElementById('offline-overlay').classList.add('show');
    });
  }

  function openLoginModal() {
    const modal = document.createElement('div');
    modal.style.cssText = 'position:fixed; inset:0; background:rgba(0,0,0,0.6); z-index:10000; display:flex; align-items:center; justify-content:center; padding:20px;';
    modal.innerHTML = `
      <div style="background:white; border-radius:20px; padding:24px; width:100%; max-width:400px; direction:rtl;" class="page-transition">
        <h3 style="font-size:18px; font-weight:900; margin-bottom:16px; color:#0f3d2e;">تسجيل الدخول - الرقم المعتمد فقط</h3>
        <div style="background:#fef3c7; border:1px solid #f59e0b; padding:12px; border-radius:12px; font-size:12px; margin-bottom:16px;">⚠️ للاختبار: استخدم الأرقام التالية - OTP دائما 123456<br>البائع: 777111222 | المشتري: 777333444</div>
        <input id="login-phone" placeholder="777111222" style="width:100%; border:1px solid #ddd; border-radius:12px; padding:12px; margin-bottom:12px; font-size:14px;" />
        <input id="login-otp" placeholder="كود OTP - 123456" style="width:100%; border:1px solid #ddd; border-radius:12px; padding:12px; margin-bottom:16px; font-size:14px;" />
        <div style="display:flex; gap:12px;">
          <button onclick="this.closest('div').parentElement.remove()" style="flex:1; border:1px solid #ddd; padding:12px; border-radius:12px; font-weight:700;">إلغاء</button>
          <button onclick="window.markabatSale.login()" style="flex:1; background:#0f3d2e; color:white; padding:12px; border-radius:12px; font-weight:900;">دخول</button>
        </div>
      </div>
    `;
    modal.onclick = (e) => { if (e.target === modal) modal.remove(); };
    document.body.appendChild(modal);
  }

  function openSellFlow() {
    if (!currentUser) {
      openLoginModal();
      return;
    }

    const sellerVehicles = mockVehicles.filter(v => v.ownerPhone === currentUser.phone);
    
    const overlay = document.createElement('div');
    overlay.id = 'sell-flow-overlay';
    overlay.style.cssText = 'position:fixed; inset:0; background:#fcfcf9; z-index:9999; overflow:auto; direction:rtl;';
    overlay.innerHTML = `
      <div style="max-width:800px; margin:0 auto; padding:20px;" class="page-transition">
        <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:24px;">
          <button onclick="document.getElementById('sell-flow-overlay').remove()" style="width:40px; height:40px; border-radius:50%; background:white; border:1px solid #eee; display:flex; align-items:center; justify-content:center;">←</button>
          <h1 style="font-size:20px; font-weight:900; color:#0f3d2e;">بيع مركبة - مسار آمن</h1>
          <div style="width:40px;"></div>
        </div>

        <!-- Stepper -->
        <div style="display:flex; align-items:center; gap:8px; margin-bottom:24px; overflow:auto; padding-bottom:8px;">
          ${[1,2,3,4,5,6,7].map(i => `<div style="display:flex; align-items:center; gap:8px;"><div style="width:32px; height:32px; border-radius:50%; background:${i===1?'#0f3d2e':'#e5e7eb'}; color:${i===1?'white':'#999'}; display:flex; align-items:center; justify-content:center; font-size:12px; font-weight:900;">${i}</div>${i<7?'<div style="width:24px; height:2px; background:#e5e7eb;"></div>':''}</div>`).join('')}
        </div>
        <div style="background:white; border-radius:16px; padding:4px; display:flex; margin-bottom:24px;">
          <div style="height:4px; background:#0f3d2e; border-radius:999px; width:14%; transition:width 0.3s;"></div>
        </div>

        <div id="sell-step-content">
          <h2 style="font-size:18px; font-weight:900; margin-bottom:16px;">1. اختر المركبة - تظهر المركبات المسجلة باسمك فقط</h2>
          <div style="display:grid; gap:12px;">
            ${sellerVehicles.map(v => `
              <div onclick="window.markabatSale.selectVehicle('${v.id}')" style="background:white; border:2px solid #eee; border-radius:16px; padding:16px; display:flex; gap:16px; cursor:pointer; transition:all 0.2s;" class="vehicle-card" data-id="${v.id}">
                <img src="${v.image}" style="width:80px; height:60px; border-radius:12px; object-fit:cover;" loading="lazy" />
                <div style="flex:1;">
                  <div style="font-weight:900; font-size:14px;">${v.brand} ${v.model}</div>
                  <div style="font-size:12px; color:#666; margin-top:4px;">لوحة: ${v.plate} | ${v.mileage.toLocaleString()} كم | ${v.color}</div>
                  <div style="font-size:11px; color:#0f3d2e; background:#f0fdf4; display:inline-block; padding:4px 8px; border-radius:999px; margin-top:6px; font-weight:700;">✓ ملكك - جاهز للنقل</div>
                </div>
              </div>
            `).join('')}
          </div>
          ${sellerVehicles.length===0 ? '<div style="text-align:center; padding:40px; color:#999;">لا توجد مركبات مسجلة باسمك<br><small>سجل دخول برقم البائع 777111222</small></div>' : ''}
        </div>
      </div>
    `;
    document.body.appendChild(overlay);
  }

  // Expose to window
  window.markabatSale = {
    openLoginModal,
    openSellFlow,
    openNotifications: function() {
      alert('🔔 الإشعارات:\n' + (notifications.length ? notifications.map(n=>`- ${n.title}`).join('\n') : 'لا توجد إشعارات - عند إنشاء طلب بيع سيصل إشعار للمشتري'));
    },
    login: function() {
      const phone = document.getElementById('login-phone').value.trim();
      const otp = document.getElementById('login-otp').value.trim();
      
      if (!mockUsers[phone]) {
        alert('رقم غير موجود - استخدم 777111222 للبائع أو 777333444 للمشتري');
        return;
      }
      if (otp !== '123456') {
        alert('كود OTP غير صحيح - استخدم 123456 للاختبار');
        return;
      }

      currentUser = mockUsers[phone];
      localStorage.setItem('markabat_current_user', JSON.stringify(currentUser));
      
      document.querySelectorAll('[id="sell-flow-overlay"], div[style*="z-index:10000"]').forEach(el=>el.remove());
      
      // Update UI to show logged user
      const badge = document.createElement('div');
      badge.style.cssText = 'position:fixed; bottom:20px; left:20px; background:#0f3d2e; color:white; padding:12px 16px; border-radius:999px; font-size:12px; font-weight:700; z-index:9998; display:flex; align-items:center; gap:8px;';
      badge.innerHTML = `👤 ${currentUser.name} | ${currentUser.phone} <button onclick="localStorage.clear(); location.reload()" style="background:#ef4444; color:white; border:none; padding:4px 8px; border-radius:999px; font-size:10px; cursor:pointer; margin-right:8px;">خروج</button>`;
      document.body.appendChild(badge);

      alert(`✅ تم تسجيل الدخول: ${currentUser.name}`);
      location.reload();
    },
    selectVehicle: function(vehicleId) {
      const vehicle = mockVehicles.find(v=>v.id===vehicleId);
      if (!vehicle) return;

      document.querySelectorAll('.vehicle-card').forEach(card => {
        card.style.borderColor = card.dataset.id === vehicleId ? '#0f3d2e' : '#eee';
        card.style.background = card.dataset.id === vehicleId ? '#f0fdf4' : 'white';
      });

      setTimeout(() => {
        const content = document.getElementById('sell-step-content');
        if (!content) return;
        
        content.innerHTML = `
          <h2 style="font-size:18px; font-weight:900; margin-bottom:8px;">2. إدخال بيانات المشتري</h2>
          <div style="background:#f8faf6; padding:16px; border-radius:12px; margin-bottom:16px; display:flex; gap:12px; align-items:center;">
            <img src="${vehicle.image}" style="width:60px; height:45px; border-radius:8px; object-fit:cover;" />
            <div><div style="font-weight:900; font-size:13px;">${vehicle.brand} ${vehicle.model}</div><div style="font-size:11px; color:#666;">${vehicle.plate}</div></div>
          </div>
          
          <label style="font-size:13px; font-weight:700; display:block; margin-bottom:8px;">رقم جوال المشتري (الرقم المعتمد)</label>
          <div style="display:flex; gap:8px; margin-bottom:16px;">
            <input id="buyer-phone-input" placeholder="777333444" style="flex:1; border:1px solid #ddd; border-radius:12px; padding:12px; font-size:14px;" />
            <button onclick="window.markabatSale.searchBuyer()" style="background:#0f3d2e; color:white; padding:12px 20px; border-radius:12px; font-weight:900; border:none; cursor:pointer;">بحث</button>
          </div>
          <div id="buyer-result"></div>
        `;
      }, 300);
    },
    searchBuyer: function() {
      const phone = document.getElementById('buyer-phone-input').value.trim();
      const resultDiv = document.getElementById('buyer-result');
      
      if (!mockUsers[phone]) {
        resultDiv.innerHTML = `<div style="background:#fef2f2; border:1px solid #fecaca; padding:12px; border-radius:12px; font-size:12px; color:#dc2626;">❌ المشتري غير موجود أو غير موثق - يجب أن يكون المشتري موثق ومسجل في المنصة</div>`;
        return;
      }

      if (phone === currentUser.phone) {
        resultDiv.innerHTML = `<div style="background:#fef2f2; border:1px solid #fecaca; padding:12px; border-radius:12px; font-size:12px; color:#dc2626;">❌ لا يمكنك بيع المركبة لنفسك</div>`;
        return;
      }

      const buyer = mockUsers[phone];
      resultDiv.innerHTML = `
        <div style="background:white; border:2px solid #0f3d2e; border-radius:16px; padding:16px; margin-bottom:16px;">
          <div style="display:flex; align-items:center; gap:12px; margin-bottom:12px;">
            <div style="width:48px; height:48px; border-radius:50%; background:#0f3d2e; color:white; display:flex; align-items:center; justify-content:center; font-weight:900;">${buyer.name[0]}</div>
            <div>
              <div style="font-weight:900; font-size:14px;">${buyer.name} ✓ موثق</div>
              <div style="font-size:12px; color:#666;">${buyer.city} | ID: ${buyer.id}</div>
            </div>
            <div style="margin-right:auto; background:#dcfce7; color:#166534; padding:4px 8px; border-radius:999px; font-size:10px; font-weight:900;">✓ موثق</div>
          </div>
          <div style="background:#f0fdf4; padding:12px; border-radius:12px; font-size:12px;">
            <strong>تم التحقق:</strong> المشتري موثق ورقم الجوال هو الرقم المعتمد في حسابه
          </div>
          <button onclick="window.markabatSale.confirmBuyer('${phone}')" style="width:100%; background:#0f3d2e; color:white; padding:12px; border-radius:12px; font-weight:900; border:none; cursor:pointer; margin-top:12px;">تأكيد المشتري - الانتقال لتحديد السعر</button>
        </div>
      `;
    },
    confirmBuyer: function(buyerPhone) {
      const buyer = mockUsers[buyerPhone];
      const content = document.getElementById('sell-step-content');
      
      content.innerHTML = `
        <h2 style="font-size:18px; font-weight:900; margin-bottom:16px;">3. تحديد سعر المركبة بالريال اليمني</h2>
        <div style="background:#f8faf6; padding:12px; border-radius:12px; margin-bottom:16px; font-size:12px;">
          المشتري: <strong>${buyer.name}</strong> | ${buyerPhone}
        </div>
        
        <label style="font-size:13px; font-weight:700; display:block; margin-bottom:8px;">سعر المركبة (YER) - يحدده البائع</label>
        <input id="vehicle-price" type="number" placeholder="10000000" style="width:100%; border:1px solid #ddd; border-radius:12px; padding:12px; font-size:14px; margin-bottom:12px;" oninput="window.markabatSale.calculateFees()" />
        
        <div id="fee-calc" style="background:white; border:1px solid #eee; border-radius:12px; padding:16px; margin-bottom:16px; font-size:12px; line-height:2;">
          <div style="display:flex; justify-content:space-between;"><span>قيمة المركبة:</span><span id="calc-vehicle">0 YER</span></div>
          <div style="display:flex; justify-content:space-between;"><span>رسوم المنصة (80 USD × 535):</span><span>42,800 YER</span></div>
          <div style="display:flex; justify-content:space-between;"><span>الرسوم الحكومية:</span><span>0 YER</span></div>
          <div style="display:flex; justify-content:space-between; border-top:1px solid #eee; padding-top:8px; margin-top:8px; font-weight:900; font-size:14px;"><span>الإجمالي يدفعه المشتري:</span><span id="calc-total" style="color:#0f3d2e;">0 YER</span></div>
          <div style="display:flex; justify-content:space-between; color:#666;"><span>البائع يستلم:</span><span id="calc-seller">0 YER</span></div>
        </div>
        
        <button onclick="window.markabatSale.createSaleRequest('${buyerPhone}')" style="width:100%; background:#0f3d2e; color:white; padding:14px; border-radius:12px; font-weight:900; border:none; cursor:pointer;">إنشاء طلب البيع وإرسال إشعار للمشتري</button>
        
        <div style="background:#fef3c7; border:1px solid #f59e0b; padding:12px; border-radius:12px; font-size:11px; margin-top:12px;">
          ⚠️ سعر الصرف مثبت: 1 USD = 535 YER - رسوم المنصة 80 USD = 42,800 YER - لا تتغير للعملية القديمة حتى لو تغير السعر لاحقا
        </div>
      `;
    },
    calculateFees: function() {
      const price = parseInt(document.getElementById('vehicle-price').value) || 0;
      const fee = 42800;
      document.getElementById('calc-vehicle').textContent = price.toLocaleString() + ' YER';
      document.getElementById('calc-total').textContent = (price + fee).toLocaleString() + ' YER';
      document.getElementById('calc-seller').textContent = price.toLocaleString() + ' YER';
    },
    createSaleRequest: function(buyerPhone) {
      const price = parseInt(document.getElementById('vehicle-price').value);
      if (!price || price <= 0) {
        alert('أدخل سعر صحيح بالريال اليمني');
        return;
      }

      // Create sale operation
      const saleId = 'SALE-' + Date.now();
      const sale = {
        id: saleId,
        vehicleId: 'v1',
        sellerId: currentUser.phone,
        sellerName: currentUser.name,
        buyerPhone: buyerPhone,
        buyerName: mockUsers[buyerPhone].name,
        vehicleAmountYER: price,
        platformFeeYER: 42800,
        totalPaidYER: price + 42800,
        sellerPayoutYER: price,
        exchangeRate: 535,
        status: 'WAITING_BUYER_APPROVAL',
        createdAt: new Date().toISOString()
      };

      localStorage.setItem('markabat_current_sale', JSON.stringify(sale));
      
      // Add notification for buyer
      const notif = {
        id: saleId,
        title: 'لديك طلب نقل ملكية مركبة',
        message: 'من ' + currentUser.name,
        saleId: saleId,
        forPhone: buyerPhone,
        createdAt: new Date().toISOString()
      };
      
      let allNotifs = JSON.parse(localStorage.getItem('markabat_notifications') || '[]');
      allNotifs.push(notif);
      localStorage.setItem('markabat_notifications', JSON.stringify(allNotifs));

      const content = document.getElementById('sell-step-content');
      content.innerHTML = `
        <div style="text-align:center; padding:40px 20px;">
          <div style="width:80px; height:80px; background:#dcfce7; border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0 auto 16px; font-size:32px;">✅</div>
          <h3 style="font-size:18px; font-weight:900; margin-bottom:8px;">تم إنشاء طلب البيع</h3>
          <p style="font-size:13px; color:#666; margin-bottom:24px;">تم إرسال إشعار للمشتري ${mockUsers[buyerPhone].name}<br>رقم العملية: ${saleId}</p>
          
          <div style="background:white; border:1px solid #eee; border-radius:12px; padding:16px; text-align:right; font-size:12px; margin-bottom:24px;">
            <div style="font-weight:900; margin-bottom:8px;">تفاصيل العملية:</div>
            <div>قيمة المركبة: ${price.toLocaleString()} YER</div>
            <div>رسوم المنصة: 42,800 YER</div>
            <div>الإجمالي: ${(price+42800).toLocaleString()} YER</div>
            <div>البائع يستلم: ${price.toLocaleString()} YER</div>
          </div>

          <div style="background:#f0fdf4; border:1px solid #bbf7d0; padding:12px; border-radius:12px; font-size:12px; margin-bottom:16px;">
            🔔 الآن سجل دخول كمشتري (${buyerPhone} / 123456) لترى الإشعار وتوافق
          </div>

          <button onclick="document.getElementById('sell-flow-overlay').remove(); localStorage.clear(); location.reload();" style="background:#0f3d2e; color:white; padding:12px 24px; border-radius:12px; font-weight:900; border:none; cursor:pointer;">إغلاق - تجربة كمشتري</button>
        </div>
      `;

      // Update notif count
      const countEl = document.getElementById('notif-count');
      if (countEl) {
        countEl.style.display = 'flex';
        countEl.textContent = allNotifs.length;
      }
    }
  };

  // Auto show logged user badge
  if (currentUser) {
    setTimeout(() => {
      const badge = document.createElement('div');
      badge.style.cssText = 'position:fixed; bottom:20px; left:20px; background:#0f3d2e; color:white; padding:12px 16px; border-radius:999px; font-size:12px; font-weight:700; z-index:9998; display:flex; align-items:center; gap:8px;';
      badge.innerHTML = `👤 ${currentUser.name} <button onclick="localStorage.clear(); location.reload()" style="background:#ef4444; color:white; border:none; padding:4px 8px; border-radius:999px; font-size:10px; cursor:pointer; margin-right:8px;">خروج</button>`;
      if (!document.querySelector('[style*="bottom:20px; left:20px"]')) {
        document.body.appendChild(badge);
      }
    }, 1000);
  }

  console.log('[Markabat V11] Modular Sale System Loaded - Old design preserved, new flow added');
})();
</script>
