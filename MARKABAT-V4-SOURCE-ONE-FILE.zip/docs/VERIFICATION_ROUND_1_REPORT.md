# MARKABAT V4 — Verification / Hardening Round 1

Date: 2026-08-11
Source: `FINAL-MARKABAT-V4-FINAL-HARDENED.zip`
Status: **HARDENING IN PROGRESS — NOT PRODUCTION READY**

## Changes completed in this round

- Prisma enum declarations normalized to valid multiline Prisma syntax.
- Payment provider references made unique to prevent duplicate provider processing.
- Financial ledger now enforces one DEBIT and one CREDIT per entry group and handles concurrent uniqueness conflicts.
- Vehicle sale locking changed to lock by `vehicleId`, allowing authorized sellers while preventing concurrent owner/delegate sales.
- `SELL_AND_RECEIVE` now requires a verified payout account with `MATCH` name status.
- Direct sale expiration remains exactly 2 hours.
- Auction auto-bid now requires a held bid deposit when the auction requires one.
- Auction finalization releases an unused vehicle lock when there is no winner.
- Auction finalize role reference to nonexistent `AUCTION_MANAGER` removed.
- OTP remains DB-backed, 4 digits, 5 minutes, 5 attempts, 60-second resend, and now includes user-based rate limiting.
- OTP responses contain no OTP value.
- Password recovery flow added with OTP, risk assessment, session invalidation through `sessionVersion`, audit logging, and sensitive-account identity requirement.
- Logout now invalidates the server session version and clears both normal and sensitive cookies.
- Vehicle media upload foundation added with MIME/magic-byte validation, SHA-256 duplicate detection, private storage, malware-scanner gate, and plate-redaction/publication gate.
- Storage provider abstraction added; unconfigured production storage returns `NOT_CONFIGURED`.
- AI vehicle-description provider abstraction added; no fabricated AI success.
- Listing view/source tracking added.
- Listing comments/reporting and conversation/message APIs added with authorization and rate limits.
- Vehicle price history is written on listing creation and price changes.
- PWA offline fallback added; API routes are not cached by the service worker.
- Production mock-provider fallback was removed/gated for payment, traffic, identity, renewal, violation and centralized provider registry paths.
- Receipt state moved from an in-memory Map to PostgreSQL Invoice storage.
- Exchange-rate state moved from in-memory Maps to PostgreSQL.
- Support attachment magic-byte validation added.
- Production CSP no longer allows `unsafe-eval`.
- `packageManager` and Node engine were declared in `package.json`.

## Static verification performed

| Check | Result | Notes |
|---|---|---|
| TypeScript syntax parse | PASS | All `.ts/.tsx` source files parsed without syntax diagnostics using the available TypeScript compiler. |
| Prisma enum syntax | PASS (static) | Invalid one-line enum declarations from the Vercel P1012 log were normalized. |
| Duplicate Prisma model names | PASS (static) | No duplicate model names detected. |
| Duplicate Prisma enum names | PASS (static) | No duplicate enum names detected. |
| Duplicate model fields | PASS (static) | No duplicate field names detected after cleanup. |
| `describe.skip` / `it.skip` | PASS | No skip declarations remain in tests. |
| `testOtp` / `devCode` search | PASS | No matches found. |
| PostgreSQL runtime | BLOCKED | No DATABASE_URL / PostgreSQL runtime was available in this environment. |
| npm install / lockfile generation | BLOCKED | Registry DNS/network unavailable (`EAI_AGAIN`). No package-lock.json could be generated here. |
| Prisma generate | BLOCKED | Prisma CLI/dependencies are not installed locally and npm registry access is unavailable. |
| Prisma migrate deploy | BLOCKED | Requires installed Prisma CLI and real PostgreSQL. |
| Typecheck | BLOCKED | Dependencies are not installed locally. |
| Unit tests | BLOCKED | Dependencies are not installed locally. |
| Integration tests | BLOCKED | Requires PostgreSQL. |
| PostgreSQL concurrency tests | BLOCKED | Requires PostgreSQL. |
| E2E | BLOCKED | Requires PostgreSQL plus real external providers. |
| Production build | BLOCKED | Dependencies/Prisma runtime unavailable in this environment. |
| SMS | NOT_CONFIGURED | Real provider required. |
| Payment | NOT_CONFIGURED | Real provider required. |
| Escrow | NOT_CONFIGURED | Real provider / legal arrangement required. |
| Traffic | NOT_CONFIGURED | Official API required. |
| KYC | NOT_CONFIGURED | Real provider required. |
| Storage | NOT_CONFIGURED | Production object storage required. |
| Malware Scanner | NOT_CONFIGURED | Real scanner required. |

## Important remaining blockers

1. Install dependencies with network access and generate `package-lock.json`.
2. Run Prisma validation/generation against the modified schema.
3. Apply a real PostgreSQL migration.
4. Run the new concurrent auction and direct-sale tests against PostgreSQL.
5. Complete real financial duplicate-payment and duplicate-payout tests.
6. Complete real E2E only after external providers are configured.
7. Verify Vercel using `Root Directory = backend` and a fresh deployment.

**This report deliberately does not label the release Production Ready.**
