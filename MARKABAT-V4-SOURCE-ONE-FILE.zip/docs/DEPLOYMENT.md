# Deployment

## Vercel
Use the Next.js application under `backend` as the deployment root. Configure `DATABASE_URL`, `JWT_SECRET`, and real provider/storage secrets in Vercel environment variables. Run Prisma generate during install/build as required by the deployment environment.

Never require a `public` output directory for Next.js. Do not deploy `.env` files.
