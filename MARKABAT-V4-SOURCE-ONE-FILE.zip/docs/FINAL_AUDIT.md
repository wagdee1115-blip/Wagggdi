# Final Audit — MARKABAT V12 → V4 Master Alignment

## Implemented in this revision
- Mobile-first RTL account navigation and unread notification badge retained.
- Phone is the primary login identifier; email remains optional.
- Registration no longer requires national ID/date of birth; those are verification-stage data.
- OTP API no longer returns a development OTP; OTP policy is 4 digits / 5 minutes / 5 attempts.
- Direct ownership-transfer expiry changed to 2 hours.
- Transfer fee is separated from exhibition commission: 80 USD transfer fee, 0 USD direct-market commission.
- Vehicle reservation flag is persisted during transfer locking.
- Auction API enforces phone verification, seller exclusion, pending-violation/legal-block checks, server time, DB transaction and anti-sniping.
- Legacy frontend sale script was neutralized so mock/localStorage sale state cannot act as the real transaction path.
- Added production-oriented data models for listings, authorizations, payout accounts, ledger, handover evidence, invoices, disputes, risk events, price history and operations.
- Added the required security/architecture documentation set.

## NOT_CONFIGURED / requires real provider
- SMS delivery.
- Payment/escrow provider and signed webhooks.
- Official government/traffic transfer API.
- Identity/KYC provider.
- Production object storage/CDN and malware scanning.

## Verification limitation
The dependency installation/build could not be completed in this environment because `npm install` timed out. Therefore this audit does not claim a successful production build. Run `npm install`, `prisma generate`, `npm run typecheck`, `npm test`, and `npm run build` in CI/Vercel before deployment.
