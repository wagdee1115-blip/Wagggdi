# MARKABAT V4 — FINAL RUNTIME VERIFICATION REPORT

Date: 2026-08-11
Scope: `MARKABAT-V4-FINAL-PRODUCTION-CANDIDATE`

## Decision

**CODE VERIFICATION = BLOCKED**

**Production Ready = NOT APPROVED**

The source was audited and the requested runtime gate was attempted. The current execution environment does not provide PostgreSQL, npm registry access, or installed project dependencies, so runtime success is not claimed.

## Environment

| Check | Status | Evidence / Reason |
|---|---|---|
| Node.js | PASS | Node v22.16.0 |
| npm | PASS | npm 10.9.2 |
| PostgreSQL client/server | BLOCKED | `psql` and `pg_isready` are unavailable |
| node_modules | BLOCKED | Dependencies are not installed |
| npm registry | BLOCKED | `npm install --package-lock-only --ignore-scripts` timed out |
| package manager | PASS | `packageManager: npm@10.9.2` |
| package-lock.json | BLOCKED | No lockfile exists; a real lockfile could not be generated without registry access |

## Prisma

| Check | Status | Reason |
|---|---|---|
| Schema source audit | PASS | `prisma/schema.prisma` contains multiline enum definitions and no one-line enum definitions |
| Prisma validate | BLOCKED | Prisma CLI/dependencies are not installed and registry access is unavailable |
| Prisma generate | BLOCKED | Same environment limitation |
| Prisma migrate deploy | BLOCKED | No PostgreSQL and no migration directory is present |
| Migration set | BLOCKED | `backend/prisma/migrations` is absent; a migration must be generated/applied in a real PostgreSQL environment |

### Important Vercel finding

The previously reported Vercel error (`P1012`, `This line is not an enum value definition`) came from the deployed schema version containing one-line enum declarations. The current candidate source was audited and **does not contain those one-line enum declarations**. This is a source-level correction, but Vercel runtime proof remains pending.

## Static test audit

| Check | Status | Evidence |
|---|---|---|
| Core tests present | PASS | Auction, sale concurrency, financial, OTP, security, E2E, state machine and core tests exist |
| `describe.skip` / `it.skip` / `test.skip` | PASS | No skipped tests found in backend tests/lib/app |
| Financial fee tests | PASS (static) | Existing tests assert 0 USD direct commission, 100 USD exhibition service, 80 USD transfer, 2.5% auction and 0 tax |
| Memory Map audit | PARTIAL | Core transaction paths were audited; legacy/mock services still contain in-memory Maps, but they are not used as the financial source of truth. These should remain isolated from production transactional paths. |

## Required runtime tests

| Test | Status | Reason |
|---|---|---|
| `npm ci` | BLOCKED | No package-lock.json and registry unavailable |
| `npx prisma validate` | BLOCKED | Dependencies unavailable |
| `npx prisma generate` | BLOCKED | Dependencies unavailable |
| `npx prisma migrate deploy` | BLOCKED | PostgreSQL unavailable and no migrations present |
| `npm run typecheck` | BLOCKED | Dependencies unavailable |
| `npm test` | BLOCKED | Vitest unavailable |
| PostgreSQL concurrent sale | BLOCKED | PostgreSQL unavailable |
| PostgreSQL concurrent bid | BLOCKED | PostgreSQL unavailable |
| Winner lock | BLOCKED | PostgreSQL unavailable |
| Double payment | BLOCKED | PostgreSQL/dependencies unavailable |
| Double payout | BLOCKED | PostgreSQL/dependencies unavailable |
| OTP race | BLOCKED | PostgreSQL/dependencies unavailable |
| Concurrent ledger | BLOCKED | PostgreSQL/dependencies unavailable |
| Direct Sale E2E | BLOCKED | Runtime dependencies/database unavailable |
| Authorization E2E | BLOCKED | Runtime dependencies/database unavailable |
| Auction E2E | BLOCKED | Runtime dependencies/database unavailable |
| Security runtime suite | BLOCKED | Runtime dependencies unavailable |
| `npm run build` | BLOCKED | Dependencies unavailable |
| `npm start` | BLOCKED | Build/runtime unavailable |
| PWA browser verification | BLOCKED | No browser/runtime deployment environment available |

## External Providers

| Provider | Status |
|---|---|
| SMS | NOT_CONFIGURED |
| Payment | NOT_CONFIGURED |
| Escrow | NOT_CONFIGURED |
| Traffic | NOT_CONFIGURED |
| KYC | NOT_CONFIGURED |
| Storage | NOT_CONFIGURED |
| Malware Scanner | NOT_CONFIGURED |
| Payout Provider | NOT_CONFIGURED |

No provider success is fabricated.

## Business Rules Audited

- Direct Market Commission = **0 USD**
- Dealer / Exhibition Service Commission = **100 USD** only when the exhibition service is selected and the sale qualifies
- Transfer Fee = **80 USD**
- Auction Fee = **2.5%**
- Taxes = **0**
- Direct Sale Expiration = **2 hours**
- OTP = **4 digits / 5 minutes / 5 attempts / 60-second resend**
- Browsing Session = **30 minutes**
- Sensitive Session = **2 minutes**
- Anti-Sniping = **120 seconds + 120 seconds**
- Payout Protection = **15 minutes configurable**
- Inspection = **OPTIONAL**
- Insurance = **OPTIONAL**

## Final assessment

The candidate contains the requested hardening work and the current Prisma source no longer exhibits the exact one-line-enum syntax that caused the earlier Vercel `P1012` failure.

However, the final runtime gate is **not proven**. The next environment must provide:

1. A real npm registry connection or a real `package-lock.json` generated by npm.
2. `npm ci` success.
3. PostgreSQL 14+ (or compatible supported PostgreSQL) with a real `DATABASE_URL`.
4. A real migration history generated from the current schema and applied with `prisma migrate deploy`.
5. Successful Prisma generate/validate.
6. Successful typecheck/tests/build/start.
7. Real PostgreSQL concurrency tests.
8. Browser/PWA runtime verification.
9. Real provider credentials before provider-specific functionality can move from `NOT_CONFIGURED`.

Until these are proven, the correct status is **BLOCKED / NOT_CONFIGURED**, not Production Ready.
