import { z } from 'zod';
import { getCurrentUser } from '@/lib/api-auth';
import { verifySalePartyOtp } from '@/lib/transfer-workflow';
const schema = z.object({ otpId: z.string().min(1), otp: z.string().regex(/^\d{4}$/) });
export async function POST(req: Request, { params }: { params: { id: string } }) {
  try {
    const u = await getCurrentUser(); if (!u) return Response.json({ ok: false, error: 'UNAUTHORIZED' }, { status: 401 });
    const p = schema.safeParse(await req.json()); if (!p.success) return Response.json({ ok: false, error: 'INVALID_INPUT' }, { status: 400 });
    const sale = await verifySalePartyOtp({ saleId: params.id, actorId: u.id, otpId: p.data.otpId, otp: p.data.otp, party: 'BUYER' });
    return Response.json({ ok: true, sale });
  } catch (e) { return Response.json({ ok: false, error: e instanceof Error ? e.message : 'BUYER_OTP_FAILED' }, { status: 400 }); }
}
