# MARKABAT / مركبات — V4 Master Alignment

The active Next.js application is under `backend/`. The legacy static frontend under `frontend/` is retained for reference/assets; it is not the transactional source of truth.

## Local verification

```bash
cd backend
npm install
npx prisma generate
npm run typecheck
npm test
npm run build
npm start
```

Configure `.env` from `.env.example`. Never commit `.env` or provider secrets.

## Production truth

External services are `NOT_CONFIGURED` until real credentials and adapters are installed and verified. Do not treat mock/test adapters as production success.
