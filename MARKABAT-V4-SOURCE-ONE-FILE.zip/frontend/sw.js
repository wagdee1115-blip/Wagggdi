
// مركبات V11 - Service Worker FIXED - Prevents White Screen - Yemen Production
const CACHE_NAME = 'markabat-v4-hardened-2026-08-11';
const urlsToCache = ['/icons/icon-192x192.png','/icons/icon-512x512.png','/brands.png','/logo.webp','/manifest.json'];

self.addEventListener('install', event => {
  console.log('[SW V11] Install');
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(urlsToCache)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', event => {
  console.log('[SW V11] Activate - Cleaning old');
  event.waitUntil(
    caches.keys().then(names => Promise.all(names.map(name => {
      if (name !== CACHE_NAME && name.startsWith('markabat-')) {
        console.log('[SW] Delete old:', name);
        return caches.delete(name);
      }
    }))).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  const req = event.request;
  const url = new URL(req.url);
  if (url.pathname.startsWith('/api/')) return;

  
  // HTML - Network first - prevents white screen
  if (req.mode === 'navigate' || req.destination === 'document' || url.pathname === '/' || url.pathname.endsWith('.html')) {
    event.respondWith(
      fetch(req).then(res => {
        const clone = res.clone();
        caches.open(CACHE_NAME).then(c => c.put(req, clone));
        return res;
      }).catch(() => caches.match(req).then(cached => cached || caches.match('/')))
    );
    return;
  }
  
  // Assets - Cache first
  if (req.destination === 'image' || req.destination === 'style' || req.destination === 'script' || url.pathname.includes('/icons/') || url.pathname.endsWith('.png') || url.pathname.endsWith('.webp') || url.pathname.endsWith('.json')) {
    event.respondWith(
      caches.match(req).then(cached => {
        if (cached) {
          fetch(req).then(r => caches.open(CACHE_NAME).then(c => c.put(req, r))).catch(()=>{});
          return cached;
        }
        return fetch(req).then(res => {
          caches.open(CACHE_NAME).then(c => c.put(req, res.clone()));
          return res;
        }).catch(()=> new Response('',{status:404}));
      })
    );
    return;
  }
  
  event.respondWith(fetch(req).catch(()=> caches.match(req)));
});

self.addEventListener('message', event => {
  if (event.data?.type === 'SKIP_WAITING') self.skipWaiting();
  if (event.data?.type === 'CLEAR_CACHE') {
    event.waitUntil(caches.keys().then(keys => Promise.all(keys.map(k => caches.delete(k)))));
  }
});
