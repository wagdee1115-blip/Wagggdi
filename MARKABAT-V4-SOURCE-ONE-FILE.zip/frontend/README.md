# Legacy frontend assets

The previous static frontend contained prototype/mock transaction flows and browser localStorage state. It is no longer an active application surface and has been removed from the transactional path.

The active application is `backend/` (Next.js). Do not restore the old mock sale flow. Use server APIs and database-backed state only.
