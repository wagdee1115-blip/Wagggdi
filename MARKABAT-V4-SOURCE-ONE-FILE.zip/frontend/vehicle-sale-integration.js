// Legacy sale integration disabled. Real sale flows must use Next.js server APIs.
// This file intentionally contains no mock users, fake OTP, localStorage state, or fake payment success.
window.MarkabatLegacySale = Object.freeze({ status: 'NOT_CONFIGURED', message: 'استخدم مسار البيع الحقيقي داخل التطبيق.' });
